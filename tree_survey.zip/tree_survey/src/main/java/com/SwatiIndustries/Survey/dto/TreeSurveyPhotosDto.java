package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TreeSurveyPhotosDto {

    private int id;
    private int treeSurveyMasId;
    private String photoTree1;
    private String photoTree2;
    private String photoTree3;
    private Boolean isIdentified;
    private String photoLeaf;
    private String photoTrunk;
    private String photoFlower;
    private String photoFruits;
    private String photoOthers;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;
}
