package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PropertyOwnerDetailsDto {

    private Integer id;
    private Integer treeSurveyMasId;

    private String ownerName;
    private String holdingNo;

    private String ownerAddress;

    private String contactNumber;

    private String emailId;
    private String aadharNo;

    private Integer createdBy;

    private LocalDateTime createdDate;
    private Integer suspendedStatus;
}

