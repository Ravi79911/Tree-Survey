package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyPhotos;
import com.SwatiIndustries.Survey.repository.TreeSurveyPhotosRepository;
import com.SwatiIndustries.Survey.service.TreeSurveyPhotosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class TreeSurveyPhotosServiceImpl implements TreeSurveyPhotosService {

    @Autowired
    TreeSurveyPhotosRepository treeSurveyPhotosRepository;

    private static final String UPLOAD_DIR_FLOWER = "D:\\tree_survey\\src\\main\\resources\\upload\\flower_photos";
    private static final String UPLOAD_DIR_FRUITS = "D:\\tree_survey\\src\\main\\resources\\upload\\fruits_photos";
    private static final String UPLOAD_DIR_LEAF = "D:\\tree_survey\\src\\main\\resources\\upload\\leaf_photos";
    private static final String UPLOAD_DIR_TREE = "D:\\tree_survey\\src\\main\\resources\\upload\\tree_photos";
    private static final String UPLOAD_DIR_TRUNK = "D:\\tree_survey\\src\\main\\resources\\upload\\trunk_photos";
    private static final String UPLOAD_DIR_OTHERS = "D:\\tree_survey\\src\\main\\resources\\upload\\others_photos";

    private void ensureUploadDirectoryExists(String uploadDir) {
        Path uploadPath = Paths.get(uploadDir);
        if (!Files.exists(uploadPath)) {
            try {
                Files.createDirectories(uploadPath);
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException("Failed to create upload directory: " + uploadDir);
            }
        }
    }

    private String handleFileUpload(MultipartFile file, String directory, String fileNamePrefix) {
        if (file != null && !file.isEmpty()) {
            String originalFilename = file.getOriginalFilename();
            String fileExtension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String newFileName = fileNamePrefix + "_" + UUID.randomUUID() + fileExtension;
            Path filePath = Paths.get(directory, newFileName);

            try {
                byte[] bytes = file.getBytes();
                Files.write(filePath, bytes);
                return newFileName;
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException("Failed to upload file: " + file.getOriginalFilename());
            }
        } else {
            System.out.println(fileNamePrefix + " is null or empty");
            return null;
        }
    }

    @Override
    public TreeSurveyPhotos createTreeSurveyPhotos(TreeSurveyPhotos treeSurveyPhotos,
                                                   MultipartFile photoTree1,
                                                   MultipartFile photoTree2,
                                                   MultipartFile photoTree3,
                                                   MultipartFile photoLeaf,
                                                   MultipartFile photoTrunk,
                                                   MultipartFile photoFlower,
                                                   MultipartFile photoFruits,
                                                   MultipartFile photoOthers) {

        treeSurveyPhotos.setCreatedDate(LocalDateTime.now());
        treeSurveyPhotos.setSuspendedStatus(0);

        ensureUploadDirectoryExists(UPLOAD_DIR_FLOWER);
        ensureUploadDirectoryExists(UPLOAD_DIR_FRUITS);
        ensureUploadDirectoryExists(UPLOAD_DIR_LEAF);
        ensureUploadDirectoryExists(UPLOAD_DIR_TREE);
        ensureUploadDirectoryExists(UPLOAD_DIR_TRUNK);
        ensureUploadDirectoryExists(UPLOAD_DIR_OTHERS);

        treeSurveyPhotos.setPhotoTree1(handleFileUpload(photoTree1, UPLOAD_DIR_TREE, "photoTree1"));
        treeSurveyPhotos.setPhotoTree2(handleFileUpload(photoTree2, UPLOAD_DIR_TREE, "photoTree2"));
        treeSurveyPhotos.setPhotoTree3(handleFileUpload(photoTree3, UPLOAD_DIR_TREE, "photoTree3"));
        treeSurveyPhotos.setPhotoLeaf(handleFileUpload(photoLeaf, UPLOAD_DIR_LEAF, "photoLeaf"));
        treeSurveyPhotos.setPhotoTrunk(handleFileUpload(photoTrunk, UPLOAD_DIR_TRUNK, "photoTrunk"));
        treeSurveyPhotos.setPhotoFlower(handleFileUpload(photoFlower, UPLOAD_DIR_FLOWER, "photoFlower"));
        treeSurveyPhotos.setPhotoFruits(handleFileUpload(photoFruits, UPLOAD_DIR_FRUITS, "photoFruits"));
        treeSurveyPhotos.setPhotoOthers(handleFileUpload(photoOthers, UPLOAD_DIR_OTHERS, "photoOthers"));

        return treeSurveyPhotosRepository.saveAndFlush(treeSurveyPhotos);
    }

    @Override
    public List<TreeSurveyPhotos> getAllTreeSurveyPhotos() {
        return treeSurveyPhotosRepository.findAll();
    }

//    @Override
//    public Resource loadPhotos(int id) throws IOException {
//        TreeSurveyPhotos treeSurveyPhotos = treeSurveyPhotosRepository.findById(id)
//                .orElseThrow(() -> new IOException("tree survey photos not found with id: " + id));
//        String[] photoPaths = {
//                treeSurveyPhotos.getPhotoTree1(),
//                treeSurveyPhotos.getPhotoTree2(),
//                treeSurveyPhotos.getPhotoTree3(),
//                treeSurveyPhotos.getPhotoLeaf(),
//                treeSurveyPhotos.getPhotoTrunk(),
//                treeSurveyPhotos.getPhotoFlower(),
//                treeSurveyPhotos.getPhotoFruits(),
//                treeSurveyPhotos.getPhotoOthers()
//        };
//        for (String photoPath : photoPaths) {
//            if (photoPath != null && !photoPath.isEmpty()) {
//                String directory = determineDirectory(photoPath);
//                Path path = Paths.get(directory, photoPath);
//                if (Files.exists(path)) {
//                    return new FileSystemResource(path.toFile());
//                }
//            }
//        }
//        throw new IOException("No photos found for id: " + id);
//    }

    @Override
    public Resource loadPhotos(int id) throws IOException {
        TreeSurveyPhotos treeSurveyPhotos = treeSurveyPhotosRepository.findById(id)
                .orElseThrow(() -> new IOException("Tree survey photos not found with id: " + id));

        // Collect all photo paths
        String[] photoPaths = {
                treeSurveyPhotos.getPhotoTree1(),
                treeSurveyPhotos.getPhotoTree2(),
                treeSurveyPhotos.getPhotoTree3(),
                treeSurveyPhotos.getPhotoLeaf(),
                treeSurveyPhotos.getPhotoTrunk(),
                treeSurveyPhotos.getPhotoFlower(),
                treeSurveyPhotos.getPhotoFruits(),
                treeSurveyPhotos.getPhotoOthers()
        };

        // Check each path for existence
        for (String photoPath : photoPaths) {
            if (photoPath != null && !photoPath.isEmpty()) {
                String directory = determineDirectory(photoPath);
                Path path = Paths.get(directory, photoPath);
                if (Files.exists(path)) {
                    return new FileSystemResource(path.toFile());
                } else {
                    System.err.println("File not found: " + path);
                }
            }
        }

        throw new IOException("No photos found for id: " + id);
    }


    //Retrive file path from database
    private String determineDirectory(String fileName) {
        if (fileName.startsWith("photoTree")) {
            return UPLOAD_DIR_TREE;
        } else if (fileName.startsWith("photoLeaf")) {
            return UPLOAD_DIR_LEAF;
        } else if (fileName.startsWith("photoTrunk")) {
            return UPLOAD_DIR_TRUNK;
        } else if (fileName.startsWith("photoFlower")) {
            return UPLOAD_DIR_FLOWER;
        } else if (fileName.startsWith("photoFruits")) {
            return UPLOAD_DIR_FRUITS;
        } else if (fileName.startsWith("photoOthers")) {
            return UPLOAD_DIR_OTHERS;
        } else {
            throw new IllegalArgumentException("Unknown file prefix for file: " + fileName);
        }
    }


    public Optional<TreeSurveyPhotos> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster) {
        return treeSurveyPhotosRepository.findByTreeSurveyMaster(treeSurveyMaster);
    }
}
