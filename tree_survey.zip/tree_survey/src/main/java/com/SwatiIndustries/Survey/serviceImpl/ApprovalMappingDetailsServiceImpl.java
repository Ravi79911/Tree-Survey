package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.exception.ResourceNotFoundException;
import com.SwatiIndustries.Survey.model.ApprovalMappingDetails;
import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.UserRoleMaster;
import com.SwatiIndustries.Survey.repository.ApprovalMappingDetailsRepository;
import com.SwatiIndustries.Survey.repository.MunicipalMasterRepository;
import com.SwatiIndustries.Survey.repository.UserRoleMasterRepository;
import com.SwatiIndustries.Survey.service.ApprovalMappingDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ApprovalMappingDetailsServiceImpl implements ApprovalMappingDetailsService {

    @Autowired
    private ApprovalMappingDetailsRepository approvalMappingDetailsRepository;

    @Autowired
    private UserRoleMasterRepository userRoleMasterRepository;

    @Autowired
    private MunicipalMasterRepository municipalMasterRepository;

    // Create a new ApprovalMappingDetails
    public ApprovalMappingDetails createApprovalMappingDetails(ApprovalMappingDetails details) {
        // Fetch and set the references (if they exist)
        if (details.getCanForwardToRole() != null) {
            UserRoleMaster canForwardToRole = userRoleMasterRepository.findById(details.getCanForwardToRole().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("UserRoleMaster", "id", details.getCanForwardToRole().getId()));
            details.setCanForwardToRole(canForwardToRole);
        }

        if (details.getRole() != null) {
            UserRoleMaster role = userRoleMasterRepository.findById(details.getRole().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("UserRoleMaster", "id", details.getRole().getId()));
            details.setRole(role);
        }

        if (details.getCanBackToRole() != null) {
            UserRoleMaster canBackToRole = userRoleMasterRepository.findById(details.getCanBackToRole().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("UserRoleMaster", "id", details.getCanBackToRole().getId()));
            details.setCanBackToRole(canBackToRole);
        }

        if (details.getMunicipalMaster() != null) {
            MunicipalMaster municipalMaster = municipalMasterRepository.findById(details.getMunicipalMaster().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("MunicipalMaster", "id", details.getMunicipalMaster().getId()));
            details.setMunicipalMaster(municipalMaster);
        }

        // Set creation and update dates
        details.setCreatedDate(LocalDateTime.now());
        details.setUpdatedDate(LocalDateTime.now());
        details.setSuspendedStatus(0);

        return approvalMappingDetailsRepository.save(details);
    }

    // Retrieve ApprovalMappingDetails by ID
    public ApprovalMappingDetails getApprovalMappingDetailsById(Integer id) {
        return approvalMappingDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ApprovalMappingDetails", "id", id));
    }

    // Update ApprovalMappingDetails
    public ApprovalMappingDetails updateApprovalMappingDetails(Integer id, ApprovalMappingDetails newDetails) {
        Optional<ApprovalMappingDetails> optionalDetails = approvalMappingDetailsRepository.findById(id);
        if (optionalDetails.isPresent()) {
            ApprovalMappingDetails existingDetails = optionalDetails.get();

            existingDetails.setCanForward(newDetails.getCanForward());
            existingDetails.setCanBackward(newDetails.getCanBackward());

            // Update UserRoleMaster references
            if (newDetails.getCanForwardToRole() != null) {
                UserRoleMaster canForwardToRole = userRoleMasterRepository.findById(newDetails.getCanForwardToRole().getId())
                        .orElseThrow(() -> new ResourceNotFoundException("UserRoleMaster", "id", newDetails.getCanForwardToRole().getId()));
                existingDetails.setCanForwardToRole(canForwardToRole);
            }

            if (newDetails.getRole() != null) {
                UserRoleMaster role = userRoleMasterRepository.findById(newDetails.getRole().getId())
                        .orElseThrow(() -> new ResourceNotFoundException("UserRoleMaster", "id", newDetails.getRole().getId()));
                existingDetails.setRole(role);
            }

            if (newDetails.getCanBackToRole() != null) {
                UserRoleMaster canBackToRole = userRoleMasterRepository.findById(newDetails.getCanBackToRole().getId())
                        .orElseThrow(() -> new ResourceNotFoundException("UserRoleMaster", "id", newDetails.getCanBackToRole().getId()));
                existingDetails.setCanBackToRole(canBackToRole);
            }

            // Update MunicipalMaster reference
            if (newDetails.getMunicipalMaster() != null) {
                MunicipalMaster municipalMaster = municipalMasterRepository.findById(newDetails.getMunicipalMaster().getId())
                        .orElseThrow(() -> new ResourceNotFoundException("MunicipalMaster", "id", newDetails.getMunicipalMaster().getId()));
                existingDetails.setMunicipalMaster(municipalMaster);
            }

            existingDetails.setCanReject(newDetails.getCanReject());
            existingDetails.setCanApproved(newDetails.getCanApproved());
            existingDetails.setCreatedDate(newDetails.getCreatedDate());
            existingDetails.setUpdatedDate(LocalDateTime.now());
            existingDetails.setSuspendedStatus(0);

            return approvalMappingDetailsRepository.save(existingDetails);
        } else {
            throw new ResourceNotFoundException("ApprovalMappingDetails", "id", id);
        }
    }

    @Override
    public List<ApprovalMappingDetails> getAllActiveApprovalMappingDetailsBySuspendedStatus(Integer suspendedStatus) {
        return approvalMappingDetailsRepository.findBySuspendedStatus(suspendedStatus);
    }


}