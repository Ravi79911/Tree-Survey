package com.SwatiIndustries.Survey.serviceImpl;


import com.SwatiIndustries.Survey.model.ComplainMitigationDetails;
import com.SwatiIndustries.Survey.repository.ComplainMitigationDetailsRepository;
import com.SwatiIndustries.Survey.service.ComplainMitigationDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ComplainMitigationDetailsServiceImpl implements ComplainMitigationDetailsService {
    @Autowired
    private ComplainMitigationDetailsRepository repository;

    public ComplainMitigationDetails create(ComplainMitigationDetails details) {
        details.setCreatedDate(LocalDateTime.now());
        return repository.save(details);
    }

    public ComplainMitigationDetails update(int id, ComplainMitigationDetails details) {
        Optional<ComplainMitigationDetails> existingDetailsOpt = repository.findById(id);

        if (existingDetailsOpt.isPresent()) {
            ComplainMitigationDetails existingDetails = existingDetailsOpt.get();

            // Update fields only if they are not null in the request payload
            if (details.getForwardDate() != null) existingDetails.setForwardDate(details.getForwardDate());
            if (details.getForwardFrom() != null) existingDetails.setForwardFrom(details.getForwardFrom());
            if (details.getForwardTo() != null) existingDetails.setForwardTo(details.getForwardTo());
            if (details.getForwardRemaks() != null) existingDetails.setForwardRemaks(details.getForwardRemaks());
            if (details.getForwardStatus() != null) existingDetails.setForwardStatus(details.getForwardStatus());
            if (details.getCreatedBy() != 0) existingDetails.setCreatedBy(details.getCreatedBy());
            if (details.getCreatedDate() != null) existingDetails.setCreatedDate(details.getCreatedDate());
            if (details.getCuttingAndPruningMaster() != null) existingDetails.setCuttingAndPruningMaster(details.getCuttingAndPruningMaster());

            return repository.save(existingDetails);
        } else {
            throw new RuntimeException("ID not found");
        }
    }
    public Optional<ComplainMitigationDetails> getById(int id) {
        return repository.findById(id);
    }
}
