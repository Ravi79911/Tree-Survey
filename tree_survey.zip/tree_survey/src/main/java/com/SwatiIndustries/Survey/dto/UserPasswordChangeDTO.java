package com.SwatiIndustries.Survey.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserPasswordChangeDTO {
    private Integer id;
    private Integer userMaster;
    private String currentPwd;
    private String lastPwd;
    private LocalDateTime changeDateTime;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
}
