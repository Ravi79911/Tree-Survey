package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.TreeCuttingPruningDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TreeCuttingPruningDetailsService {

    List<TreeCuttingPruningDetails> save(List<Integer> treeSurveyMasterIds, int cuttingAndPruningMasterId);
    Optional<TreeCuttingPruningDetails> findById(int id);
    List<TreeCuttingPruningDetails> findByCuttingAndPruningMasterId(int cuttingAndPruningMasterId);
}
