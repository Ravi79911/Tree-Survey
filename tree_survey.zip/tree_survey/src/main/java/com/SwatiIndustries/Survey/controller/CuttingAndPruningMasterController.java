package com.SwatiIndustries.Survey.controller;



import com.SwatiIndustries.Survey.dto.CuttingAndPruningMasterDTO;
import com.SwatiIndustries.Survey.model.CuttingAndPruningMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.service.CuttingAndPruningMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/cutting-and-pruning")
@CrossOrigin
public class CuttingAndPruningMasterController {

    @Autowired
    private CuttingAndPruningMasterService cuttingAndPruningMasterService;


    @PostMapping("/save")
    public ResponseEntity<CuttingAndPruningMaster> saveCuttingAndPruningMaster(
            @Valid @RequestBody CuttingAndPruningMaster master) {
        CuttingAndPruningMaster savedMaster = cuttingAndPruningMasterService.saveCuttingAndPruningMaster(master);
        return new ResponseEntity<>(savedMaster, HttpStatus.CREATED);
    }

//    @GetMapping("/all")
//    public ResponseEntity<List<CuttingAndPruningMasterDTO>> getAllCuttingAndPruningMasters() {
//        try {
//            List<CuttingAndPruningMasterDTO> masters = cuttingAndPruningMasterService.getAllCuttingAndPruningMasters();
//            return new ResponseEntity<>(masters, HttpStatus.OK);
//        } catch (Exception e) {
//            e.printStackTrace(); // Log the error
//            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

    @GetMapping("/active")
    public ResponseEntity<List<CuttingAndPruningMaster>> getAllActiveCuttingAndPruningMaster(@RequestParam(required = false, defaultValue = "0") Integer status){
        List<CuttingAndPruningMaster> cuttingAndPruningMasters=cuttingAndPruningMasterService.findAllActiveCuttingAndPruningMaster(status);
        return ResponseEntity.ok(cuttingAndPruningMasters);

    }

}