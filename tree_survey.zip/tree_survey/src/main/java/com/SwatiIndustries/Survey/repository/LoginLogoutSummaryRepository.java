package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.LoginLogoutSummary;
import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface LoginLogoutSummaryRepository extends JpaRepository<LoginLogoutSummary, Integer> {

//    Optional<LoginLogoutSummary> findByUserMaster(UserMaster userMaster);
}
