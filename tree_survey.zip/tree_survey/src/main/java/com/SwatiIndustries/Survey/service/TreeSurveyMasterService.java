package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.dto.TreeSurveyMasterDto;
import com.SwatiIndustries.Survey.dto.TreeSurveyResponseDTO;
import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.model.ZoneWard;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TreeSurveyMasterService {

    TreeSurveyMaster createTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster);

    List<TreeSurveyMaster> getAllTreeSurveyMasters();

    TreeSurveyResponseDTO getTreeSurveyDetailsByTreeUUID(String treeUUID);

    Optional<TreeSurveyMaster> findById(Integer id);

    TreeSurveyMaster patchTreeSurveyMasterSuspendedStatus(int id, int suspendedStatus);

    List<TreeSurveyMaster> findByTreeName(String treeName);

     List<TreeSurveyMasterDto> getTreeSurveysByWhereCondition(int municipalId, int zoneId, int zoneWardId);

    List<TreeSurveyMaster> getTreeSurveyMastersByOwnershipOfLandAndFilters(
            String ownershipOfLand, int municipalId, int zoneId, int zoneWardId, String treeName);

    TreeSurveyMaster updateTreeSurvey(int id, TreeSurveyMaster treeSurveyMasterDetails);

    List<TreeSurveyMaster> findAllActiveTreeSurveyMaster(Integer status);
}
