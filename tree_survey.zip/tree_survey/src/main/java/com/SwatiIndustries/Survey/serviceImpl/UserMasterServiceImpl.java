package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.repository.UserMasterRepository;
import com.SwatiIndustries.Survey.service.UserMasterService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserMasterServiceImpl implements UserMasterService {

    @Autowired
    private UserMasterRepository userMasterRepository;

    private static final String uploadDir = "D:\\tree_survey\\src\\main\\resources\\upload\\user_photos";

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();


    public UserMaster saveUserMaster(UserMaster userMaster, MultipartFile photoFile) throws IOException {
        // Encode the password
        userMaster.setPassword(passwordEncoder.encode(userMaster.getPassword()));
        userMaster.setCreatedDate(LocalDateTime.now());
        userMaster.setUpdatedDate(LocalDateTime.now());
        userMaster.setSuspendedStatus(0);

        // Handle file saving
        if (photoFile != null && !photoFile.isEmpty()) {
            String fileName = userMaster.getUserName() + "_" + photoFile.getOriginalFilename();
            //String uploadDir = "user_photos/";
            Path path = Paths.get(uploadDir, fileName);

            // Create directories if they don't exist
            Files.createDirectories(path.getParent());

            // Save the file to the directory
            Files.write(path, photoFile.getBytes());

            // Set the photo path in the userMaster object
            userMaster.setUserPhoto(path.toString());
        }

        // Set created date
        userMaster.setCreatedDate(LocalDateTime.now());

        return userMasterRepository.save(userMaster);
    }

    @Override
    public List<UserMaster> getUsersBySuspendedStatus(Integer suspendedStatus) {
        return userMasterRepository.findBySuspendedStatus(suspendedStatus);
    }

    @Override
    public UserMaster updateUserMasterById(Integer id, UserMaster updatedUserMaster, MultipartFile photoFile) throws IOException {
        Optional<UserMaster> existingUserOpt = userMasterRepository.findById(id);

        if (existingUserOpt.isPresent()) {
            UserMaster existingUser = existingUserOpt.get();

            // Update fields
            existingUser.setNameOff(updatedUserMaster.getNameOff());
            existingUser.setDesignation(updatedUserMaster.getDesignation());
            existingUser.setDepartment(updatedUserMaster.getDepartment());
            existingUser.setMunicipalMasterid(updatedUserMaster.getMunicipalMasterid());
            existingUser.setUserRoleMasterid(updatedUserMaster.getUserRoleMasterid());
            existingUser.setMobileNo(updatedUserMaster.getMobileNo());
            existingUser.setEmailId(updatedUserMaster.getEmailId());
            existingUser.setUserName(updatedUserMaster.getUserName());

            // Encode password if it is updated
            if (updatedUserMaster.getPassword() != null) {
                existingUser.setPassword(passwordEncoder.encode(updatedUserMaster.getPassword()));
            }

            // Handle photo update
            if (photoFile != null && !photoFile.isEmpty()) {
                String fileName = updatedUserMaster.getUserName() + "_" + photoFile.getOriginalFilename();
                Path path = Paths.get(uploadDir, fileName);
                Files.createDirectories(path.getParent());
                Files.write(path, photoFile.getBytes());
                existingUser.setUserPhoto(path.toString());
            }

            existingUser.setUpdatedDate(LocalDateTime.now());

            return userMasterRepository.save(existingUser);
        } else {
            throw new EntityNotFoundException("User not found with ID: " + id);
        }
    }


}

