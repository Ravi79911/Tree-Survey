package com.SwatiIndustries.Survey.service;


import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.model.UserPasswordChange;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface UserPasswordChangeService {

    UserPasswordChange createUserPasswordChange(UserPasswordChange request);
    UserPasswordChange updateUserPasswordChange(Integer id, UserPasswordChange request);
    Optional<UserPasswordChange> getUserMasterId(UserMaster userMaster);
}
