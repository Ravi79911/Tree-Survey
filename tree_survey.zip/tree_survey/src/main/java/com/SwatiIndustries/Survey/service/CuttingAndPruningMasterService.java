package com.SwatiIndustries.Survey.service;



import com.SwatiIndustries.Survey.dto.CuttingAndPruningMasterDTO;
import com.SwatiIndustries.Survey.model.CuttingAndPruningMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CuttingAndPruningMasterService {


    CuttingAndPruningMaster saveCuttingAndPruningMaster(CuttingAndPruningMaster master);
    List<CuttingAndPruningMasterDTO> getAllCuttingAndPruningMasters();

    List<CuttingAndPruningMaster> findAllActiveCuttingAndPruningMaster(Integer status);

}
