package com.SwatiIndustries.Survey.repository;


import com.SwatiIndustries.Survey.model.MunicipalMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface MunicipalMasterRepository extends JpaRepository<MunicipalMaster, Integer> {

     List<MunicipalMaster> findBySuspendedStatus(Integer status) ;

    List<MunicipalMaster> findByMuniName(String muniName);
}