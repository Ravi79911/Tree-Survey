package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.dto.CuttingAndPruningMasterDTO;
import com.SwatiIndustries.Survey.dto.MunicipalMasterDto;
import com.SwatiIndustries.Survey.dto.ZoneDto;
import com.SwatiIndustries.Survey.dto.ZoneWardDto;
import com.SwatiIndustries.Survey.model.CuttingAndPruningMaster;
import com.SwatiIndustries.Survey.repository.CuttingAndPruningMasterRepository;
import com.SwatiIndustries.Survey.service.CuttingAndPruningMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class CuttingAndPruningMasterServiceImpl implements CuttingAndPruningMasterService {

    @Autowired
    private CuttingAndPruningMasterRepository cuttingAndPruningMasterRepository;

    public CuttingAndPruningMaster saveCuttingAndPruningMaster(CuttingAndPruningMaster master) {
        master.setSuspendedStatus(0);
        master.setCreatedDate(LocalDateTime.now());
        master.setUpdatedDate(LocalDateTime.now());
        return cuttingAndPruningMasterRepository.saveAndFlush(master);
    }

    public List<CuttingAndPruningMasterDTO> getAllCuttingAndPruningMasters() {
        List<CuttingAndPruningMaster> masters = cuttingAndPruningMasterRepository.findAll();
        return masters.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CuttingAndPruningMaster> findAllActiveCuttingAndPruningMaster(Integer status) {
        return cuttingAndPruningMasterRepository.findBySuspendedStatus(status);
    }

    private CuttingAndPruningMasterDTO convertToDTO(CuttingAndPruningMaster master) {
        if (master == null) {
            return null;
        }

        CuttingAndPruningMasterDTO dto = new CuttingAndPruningMasterDTO();
        dto.setId(master.getId());
        dto.setApplyFrom(master.getApplyFrom());

        // Convert related entities directly
        MunicipalMasterDto municipalMasterDTO = new MunicipalMasterDto();
        municipalMasterDTO.setId(master.getMunicipalMaster().getId());
        municipalMasterDTO.setMuniCode(master.getMunicipalMaster().getMuniCode());
        municipalMasterDTO.setCity(master.getMunicipalMaster().getCity());
        municipalMasterDTO.setState(master.getMunicipalMaster().getState());
        municipalMasterDTO.setTollFreeNumber(master.getMunicipalMaster().getTollFreeNumber());
        municipalMasterDTO.setAddressLine1(master.getMunicipalMaster().getAddressLine1());
        municipalMasterDTO.setAddressLine2(master.getMunicipalMaster().getAddressLine2());
        municipalMasterDTO.setMuniName(master.getMunicipalMaster().getMuniName()); // Adjust field mapping as needed
        dto.setMunicipalMaster(municipalMasterDTO);

        ZoneDto zoneDTO = new ZoneDto();
        zoneDTO.setId(master.getZone().getId());
        zoneDTO.setZoneName(master.getZone().getZoneName()); // Adjust field mapping as needed
        dto.setZone(zoneDTO);

        ZoneWardDto zoneWardDTO = new ZoneWardDto();
        zoneWardDTO.setId(master.getZoneWard().getId());
        zoneWardDTO.setWardNo(master.getZoneWard().getWardNo()); // Adjust field mapping as needed
        dto.setZoneWard(zoneWardDTO);

        dto.setApplyFor(master.getApplyFor());
        dto.setApplicantName(master.getApplicantName());
        dto.setMobileNo(master.getMobileNo());
        dto.setEmailId(master.getEmailId());
        dto.setAddress(master.getAddress());
        dto.setDesignation(master.getDesignation());
        dto.setDepartment(master.getDepartment());
        dto.setPurpose(master.getPurpose());
        dto.setRequestRemarks(master.getRequestRemarks());
        dto.setCreatedBy(master.getCreatedBy());
        dto.setCreatedDate(master.getCreatedDate());
        dto.setUpdatedBy(master.getUpdatedBy());
        dto.setUpdatedDate(master.getUpdatedDate());
        dto.setSuspendedStatus(master.getSuspendedStatus());

        return dto;
    }
}







