package com.SwatiIndustries.Survey.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class TreeSurveyStatusDTO {

    private Integer id;
    private Integer treeSurveyMasId;

    private Boolean isApproved;
    private Boolean isUpdate;
    private Boolean isRejected;
    private Integer createdBy;
    private LocalDateTime createdDate;
    private Integer suspendedStatus;
}
