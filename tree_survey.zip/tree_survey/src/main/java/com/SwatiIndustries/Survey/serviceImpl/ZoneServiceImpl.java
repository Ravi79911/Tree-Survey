package com.SwatiIndustries.Survey.serviceImpl;


import com.SwatiIndustries.Survey.dto.ZoneDto;
import com.SwatiIndustries.Survey.model.Zone;
import com.SwatiIndustries.Survey.repository.ZoneRepository;
import com.SwatiIndustries.Survey.service.ZoneService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ZoneServiceImpl implements ZoneService {

    @Autowired
    private ZoneRepository zoneRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<ZoneDto> findAll() {
        List<Zone> zones = zoneRepository.findAll();
        return zones.stream()
                .map(zone -> modelMapper.map(zone, ZoneDto.class))
                .collect(Collectors.toList());
    }

//    @Override
//    public Zone updateZone(int id, Zone updatedZone, int updatedBy) {
//        Optional<Zone> zoneOptional = zoneRepository.findById(id);
//        if (zoneOptional.isPresent()) {
//            Zone existingZone = zoneOptional.get();
//            existingZone.setZoneName(updatedZone.getZoneName());
//            existingZone.setUpdatedBy(updatedBy);
////            existingZone.setUpdatedBy(getCurrentUser());
//            existingZone.setUpdatedDate(LocalDateTime.now());
//            existingZone.setSuspendedStatus(updatedZone.getSuspendedStatus());
//            existingZone.setMunicipalId(updatedZone.getMunicipalId());
//
//            return zoneRepository.saveAndFlush(existingZone);
//        } else {
//            throw new RuntimeException("Zone not found with id: " + id);
//        }
//    }

//    @Override
//    public List<Zone> getAllActiveZones(int status) {  // 0 means active
//        return zoneRepository.findBySuspendedStatus(status);
//    }

    @Override
    public Zone findZoneById(int id) {
        Optional<Zone> zone = zoneRepository.findZoneById(id);
        return zone.orElse(null);
    }

//    public Zone deleteZoneById(int zoneId, int status, int updatedBy) {
//        Zone zone = findZoneById(zoneId);
//        if(zone != null) {
//            zone.setSuspendedStatus(status);
//            zone.setUpdatedDate(LocalDateTime.now());
//            zone.setUpdatedBy(updatedBy);
//            return zoneRepository.saveAndFlush(zone);
//        }
//        return null;
//    }

    @Override
    public Zone createZone(Zone zone) {

        LocalDateTime currentDateTime = LocalDateTime.now();
        zone.setCreatedDate(currentDateTime);
        zone.setUpdatedDate(currentDateTime);
        zone.setSuspendedStatus(0); // 0 means active

        return zoneRepository.saveAndFlush(zone);
    }

    // Method to get all zones by Municipal ID
    public List<ZoneDto> getZonesByMunicipalId(int municipalId) {
        List<Zone> zones = zoneRepository.findByMunicipalId(municipalId);
        return zones.stream()
                .map(zone -> modelMapper.map(zone, ZoneDto.class))
                .collect(Collectors.toList());
    }

//    private String getCurrentUser() {
    // Fetch the current authenticated user's username or identifier
    // Example using Spring Security:
//        return SecurityContextHolder.getContext().getAuthentication().getName();
//    }


}

