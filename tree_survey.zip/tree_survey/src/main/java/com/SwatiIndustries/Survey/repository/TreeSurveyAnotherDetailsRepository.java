package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.TreeSurveyAnotherDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface TreeSurveyAnotherDetailsRepository extends JpaRepository<TreeSurveyAnotherDetails, Integer> {
    Optional<TreeSurveyAnotherDetails> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster);

    List<TreeSurveyAnotherDetails> getAllBySuspendedStatus(Integer status);
}
