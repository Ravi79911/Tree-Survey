package com.SwatiIndustries.Survey.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_tree_survey_prvt_prop_owner_details")
public class PropertyOwnerDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

//    @Column(name = "tree_survey_mas_id", nullable = false)
//    @NotNull(message = "Tree Survey Master ID is required")
//    private int treeSurveyMasId;

    @Column(name = "owner_name", nullable = false)
    @NotBlank(message = "Owner name is required")
    private String ownerName;

    @Column(name = "holding_no")
    private String holdingNo;

    @Column(name = "owner_address", nullable = false)
    @NotBlank(message = "Owner address is required")
    private String ownerAddress;

    @Column(name = "contact_number", nullable = false)
    @NotBlank(message = "Contact number is required")
    private String contactNumber;

    @Column(name = "email_id")
    @Email(message = "Email should be valid")
    private String emailId;

    @Column(name = "aadhar_no")
    private String aadharNo;

    @Column(name = "createdby", nullable = false)
    @NotNull(message = "Created by is required")
    private int createdBy;

    @Column(name = "createddate", nullable = false)
    @NotNull(message = "Created date is required")
    private LocalDateTime createdDate;

    @Column(name = "suspendedstatus")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "tree_survey_mas_id", referencedColumnName = "id", nullable = false)
    @NotNull(message = "Tree Survey Master ID is required")
    private TreeSurveyMaster treeSurveyMaster;
}