package com.SwatiIndustries.Survey.repository;



import com.SwatiIndustries.Survey.model.Zone;
import com.SwatiIndustries.Survey.model.ZoneWard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ZoneWardRepository extends JpaRepository<ZoneWard, Integer> {

    List<ZoneWard> findByWardNo(String wardNo);

    List<ZoneWard> findByMunicipalMasterId(int municipalId);

    //List<ZoneWard> findByZoneId(int zoneId);

    @Query("SELECT zw FROM ZoneWard zw WHERE zw.zone.id = :zoneId")
    List<ZoneWard> findByZoneId(int zoneId);

}
