package com.SwatiIndustries.Survey.serviceImpl;


import com.SwatiIndustries.Survey.dto.MunicipalMasterDto;
import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.repository.MunicipalMasterRepository;
import com.SwatiIndustries.Survey.service.MunicipalMasterService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class MunicipalMasterServiceImpl implements MunicipalMasterService {

    private static final String UPLOAD_DIR = "D:\\tree_survey\\src\\main\\resources\\upload\\muncipal_log";

    @Autowired
    MunicipalMasterRepository municipalMasterRepository;

    @Autowired
    ModelMapper modelMapper;


    @Override
    public MunicipalMaster createMunicipalMaster(MunicipalMaster municipalMaster, MultipartFile logoFile) {
        municipalMaster.setCreatedDate(LocalDateTime.now());
        municipalMaster.setUpdatedDate(LocalDateTime.now());
        municipalMaster.setSuspendedStatus(0);

        if (logoFile != null && !logoFile.isEmpty()) {
            String originalFilename = logoFile.getOriginalFilename();
            String fileExtension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String newFileName = "logo_" + UUID.randomUUID() + fileExtension;
            try {
                // Ensure directory exists
                File dir = new File(UPLOAD_DIR);
                if (!dir.exists()) {
                    dir.mkdirs(); // Create directories if they don't exist
                }

                byte[] bytes = logoFile.getBytes();
                Path path = Paths.get(UPLOAD_DIR, newFileName);
                Files.write(path, bytes);
                municipalMaster.setLogoFile(newFileName);
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException("Failed to save logo file", e); // Throw runtime exception in case of failure
            }
        } else {
            System.out.println("Uploaded file is null or empty");
        }
        System.out.println("UPLOAD_DIR: " + UPLOAD_DIR);
        System.out.println("logoFile: " + logoFile);
        return municipalMasterRepository.saveAndFlush(municipalMaster);
    }

    @Override
    public List<MunicipalMasterDto> getAllMunicipalMaster() {
        return municipalMasterRepository.findAll().stream().map(municipalMaster -> modelMapper.map(municipalMaster, MunicipalMasterDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<MunicipalMaster> getMunicipalMasterById(int id) {
        return municipalMasterRepository.findById(id);
    }

    @Override
    public List<MunicipalMaster> getMunicipalMasterByMuniName(String muniName) {
        return municipalMasterRepository.findByMuniName(muniName);
    }

    @Override
    public MunicipalMaster updateMunicipalMasterById(int id, MunicipalMaster municipalMaster) {
        municipalMaster.setId(id);
        municipalMaster.setUpdatedDate(LocalDateTime.now());
        return municipalMasterRepository.saveAndFlush(municipalMaster);
    }

    @Override
    public MunicipalMaster patchMunicipalMasterSuspendedStatus(int id, int suspendedStatus) {
        Optional<MunicipalMaster> patchMunicipalMaster = municipalMasterRepository.findById(id);
        if (patchMunicipalMaster.isPresent()) {
            MunicipalMaster existingMunicipalMaster = patchMunicipalMaster.get();
            existingMunicipalMaster.setSuspendedStatus(suspendedStatus);
            existingMunicipalMaster.setUpdatedDate(LocalDateTime.now());
            return municipalMasterRepository.saveAndFlush(existingMunicipalMaster);
        } else {
            throw new RuntimeException("municipal master not found with id: " + id);
        }
    }

    @Override
    public Resource loadLogo(int id) throws IOException {
        MunicipalMaster municipalMaster = municipalMasterRepository.findById(id)
                .orElseThrow(() -> new IOException("municipal master not found with id: " + id));
        String fileName = municipalMaster.getLogoFile();
        if (fileName == null || fileName.isEmpty()) {
            throw new IOException("logo file not found for id: " + id);
        }
        Path path = Paths.get(UPLOAD_DIR, fileName);
        return new FileSystemResource(path.toFile());
    }

    @Override
    public List<MunicipalMaster> findAllActiveMunicipalMaster(Integer status) {
        return municipalMasterRepository.findBySuspendedStatus(status);
    }

}
