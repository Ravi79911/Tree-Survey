package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.TreeSurveyStatus;
import com.SwatiIndustries.Survey.service.TreeSurveyStatusService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tree-survey-status")
@Validated
@CrossOrigin
public class TreeSurveyStatusController {

    @Autowired
    private TreeSurveyStatusService service;

    @GetMapping("/All")
    public List<TreeSurveyStatus> getAllStatuses() {
        return service.findAll();
    }

    @PostMapping("/save")
    public ResponseEntity<TreeSurveyStatus> createStatus(@Valid @RequestBody TreeSurveyStatus status) {
        TreeSurveyStatus savedStatus = service.saveTreeSurveyStatus(status);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedStatus);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TreeSurveyStatus> getStatusById(@PathVariable Integer id) {
        Optional<TreeSurveyStatus> status = service.findById(id);
        return status.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

//    @PutMapping("/{id}")
//    public ResponseEntity<TreeSurveyStatus> updateStatus(@PathVariable Integer id, @Valid @RequestBody TreeSurveyStatus status) {
//        if (service.findById(id).isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//        status.setId(id);
//        TreeSurveyStatus updatedStatus = service.saveTreeSurveyStatus(status);
//        return ResponseEntity.ok(updatedStatus);
//    }

}
