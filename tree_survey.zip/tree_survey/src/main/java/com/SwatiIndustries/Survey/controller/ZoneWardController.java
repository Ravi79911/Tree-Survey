package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.dto.ZoneWardDto;
import com.SwatiIndustries.Survey.model.Zone;
import com.SwatiIndustries.Survey.model.ZoneWard;
import com.SwatiIndustries.Survey.service.ZoneWardService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class ZoneWardController {

    @Autowired
    ZoneWardService zoneWardService;

    @PostMapping("/zoneWard")
    public ResponseEntity<ZoneWard> createZoneWards(@Valid @RequestBody ZoneWard zoneWard) {
        ZoneWard createZone = zoneWardService.createZoneWard(zoneWard);
        return ResponseEntity.status(HttpStatus.CREATED).body(createZone);
    }

    @GetMapping("/getAllWards")
    public ResponseEntity<List<ZoneWardDto>> getAllZoneWards() {
        List<ZoneWardDto> zoneWards = zoneWardService.getAllZoneWard();
        return ResponseEntity.ok(zoneWards);
    }

//    @GetMapping("/wardNo")
//    public List<ZoneWard> getByWardNos(@RequestParam("wardNo") String wardNo) {
//        return zoneWardService.getByWardNo(wardNo);
//    }

//    @GetMapping("/zoneWard/{id}")
//    public ResponseEntity<Object> getZoneWardById(@PathVariable int id) {
//        Optional<ZoneWard> zoneWard = zoneWardService.getZoneWardById(id);
//        if (zoneWard.isPresent()) {
//            return ResponseEntity.ok(zoneWard.get());
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
//        }
  //  }

    @GetMapping("/geZoneWardByMunicipalId")
    public List<ZoneWard> getZoneWardByMunicipalId(@RequestParam int municipalId) {
        return zoneWardService.getZoneWardByMunicipalId(municipalId);
    }

    // API to find ZoneWards by Zone ID
    @GetMapping("/zone/{zoneId}")
    public ResponseEntity<List<ZoneWardDto>> getZoneWardsByZoneId(@PathVariable int zoneId) {
        List<ZoneWardDto> zoneWards = zoneWardService.getZoneWardsByZoneId(zoneId);
        return ResponseEntity.ok(zoneWards);
    }
//
//    @PutMapping("/update/{id}")
//    public ResponseEntity<ZoneWard> updateZoneWardById(@PathVariable int id, @RequestBody ZoneWard zoneWard) {
//        ZoneWard updateZoneWard = zoneWardService.updateZoneWard(id, zoneWard);
//        return ResponseEntity.ok(updateZoneWard);
//    }
//
//    @PatchMapping("/ward/suspendedStatus/{id}")
//    public ResponseEntity<ZoneWard> patchSuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
//        ZoneWard patchedZoneWard = zoneWardService.patchSuspendedStatus(id, suspendedStatus);
//        return ResponseEntity.ok(patchedZoneWard);
//    }

}
