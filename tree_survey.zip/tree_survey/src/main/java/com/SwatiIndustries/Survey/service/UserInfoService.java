package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface UserInfoService {

    UserInfo saveUserInfo(UserInfo userDetails);

    List<UserInfo> getAllActiveUsersBySuspendedStatus(Integer suspendedStatus);
    Optional<UserInfo> getUserMasterId(UserMaster userMaster);
}
