package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.PropertyOwnerDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.repository.PropertyOwnerDetailsRepository;
import com.SwatiIndustries.Survey.service.PropertyOwnerDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PropertyOwnerDetailsServiceImpl implements PropertyOwnerDetailsService {


    private final PropertyOwnerDetailsRepository propertyOwnerDetailsRepository;

    @Autowired
    public PropertyOwnerDetailsServiceImpl(PropertyOwnerDetailsRepository propertyOwnerDetailsRepository) {
        this.propertyOwnerDetailsRepository = propertyOwnerDetailsRepository;
    }

    @Override
    public PropertyOwnerDetails savePropertyOwnerDetails(PropertyOwnerDetails propertyOwnerDetails) {
        propertyOwnerDetails.setSuspendedStatus(0);
        propertyOwnerDetails.setCreatedDate(LocalDateTime.now());
        return propertyOwnerDetailsRepository.saveAndFlush(propertyOwnerDetails);
    }

    @Override
    public List<PropertyOwnerDetails> getAllPropertyOwnerDetails() {
        return propertyOwnerDetailsRepository.findAll();
    }

    @Override
    public List<PropertyOwnerDetails> getPropertyOwnerDetailsByTreeSurveyMasterId(int treeSurveyMasterId) {
        return propertyOwnerDetailsRepository.findByTreeSurveyMasterId(treeSurveyMasterId);
    }

    @Override
    public List<PropertyOwnerDetails> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster) {
        return propertyOwnerDetailsRepository.findByTreeSurveyMaster(treeSurveyMaster);
    }

    @Override
    public Optional<PropertyOwnerDetails> findById(Integer id) {
        return propertyOwnerDetailsRepository.findById(id);
    }

    @Override
    public PropertyOwnerDetails patchPropertyOwnerDetailsSuspendedStatus(int id, int suspendedStatus) {
       Optional<PropertyOwnerDetails> patchPropertyOwner=propertyOwnerDetailsRepository.findById(id);
       if (patchPropertyOwner.isPresent()){
           PropertyOwnerDetails existingPropertyOwnerDetails=patchPropertyOwner.get();
           existingPropertyOwnerDetails.setSuspendedStatus(suspendedStatus);
           return propertyOwnerDetailsRepository.saveAndFlush(existingPropertyOwnerDetails);
       }else {
           throw new RuntimeException("PropertyOwnerDetails not found with id: " + id);
       }
    }

}