package com.SwatiIndustries.Survey.service;


import com.SwatiIndustries.Survey.model.ComplainMitigationDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface ComplainMitigationDetailsService {
    Optional<ComplainMitigationDetails> getById(int id);
    ComplainMitigationDetails update(int id, ComplainMitigationDetails details);
    ComplainMitigationDetails create(ComplainMitigationDetails details);

}