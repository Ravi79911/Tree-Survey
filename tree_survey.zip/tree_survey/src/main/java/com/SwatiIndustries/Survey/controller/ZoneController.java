package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.dto.ZoneDto;
import com.SwatiIndustries.Survey.model.Zone;
import com.SwatiIndustries.Survey.service.ZoneService;
import com.SwatiIndustries.Survey.serviceImpl.ZoneServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/zone")
@CrossOrigin
public class ZoneController {

    @Autowired
    private ZoneService zoneService;

//     Get all zones
    @GetMapping("/all")
    public ResponseEntity<List<ZoneDto>> getAll() {
        List<ZoneDto> zones = zoneService.findAll();
        return ResponseEntity.ok(zones);
    }

//     Get all active zones
//    @GetMapping("/active")
//    public ResponseEntity<List<Zone>> getAllActiveZones(@RequestParam(required = false, defaultValue = "0") Integer status) {
//        List<Zone> activeZones = zoneService.getAllActiveZones(status);
//        return ResponseEntity.ok(activeZones);
//    }

////     Get all zones by municipal ID for user dropdown
//    @GetMapping("/municipal/{municipalId}")
//    public ResponseEntity<?> findByMunicipalID(@PathVariable int municipalId) {
//        List<Zone> zones = zoneService.findAllByMunicipalId(municipalId);
//        if (zones.isEmpty()) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                    .body("No zone found with municipal id: " + municipalId);
//        }
//        return ResponseEntity.ok(zones);
//    }

//     Update a zone for admin
//    @PutMapping("/{zoneId}")
//    public ResponseEntity<Zone> updateZone(@PathVariable("zoneId") int id, @RequestBody Zone updatedZone) {
//        try {
//            Zone updated = zoneService.updateZone(id, updatedZone, 1);
//            return ResponseEntity.ok(updated);
//        } catch (RuntimeException e) {
//            return ResponseEntity.notFound().build();
//        }
//    }

//    Mark zone as not suspended for admin
//    @PatchMapping("/delete/{zoneId}")
//    public ResponseEntity<Void> deleteZoneById(@PathVariable int zoneId, @RequestParam(required = false, defaultValue = "1") Integer status) {
//        zoneService.deleteZoneById(zoneId,status,1);
//        return ResponseEntity.noContent().build();
//    }

//    find zone by id
//    @GetMapping("/{id}")
//    public ResponseEntity<Zone> getZoneById(@PathVariable int id) {
//        Zone zone = zoneService.findZoneById(id);
//        return ResponseEntity.ok(zone);
//    }

//   Save a new zone for admin
    @PostMapping("/create")
    public ResponseEntity<Zone> createZone(@Valid @RequestBody Zone zone) {
        Zone createdZone = zoneService.createZone(zone);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdZone);
    }

    // API to find zones by Municipal ID
    @GetMapping("/municipal/{municipalId}")
    public ResponseEntity<List<ZoneDto>> getZonesByMunicipalId(@PathVariable int municipalId) {
        List<ZoneDto> zones = zoneService.getZonesByMunicipalId(municipalId);
        return ResponseEntity.ok(zones);
    }

}
