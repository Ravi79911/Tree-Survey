package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.model.ComplainMitigationDetails;
import com.SwatiIndustries.Survey.service.ComplainMitigationDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/complain-mitigation-details")
@CrossOrigin
public class ComplainMitigationDetailsController {


    @Autowired
    private ComplainMitigationDetailsService service;

    @PostMapping
    public ResponseEntity<ComplainMitigationDetails> create(@RequestBody ComplainMitigationDetails details) {
        ComplainMitigationDetails savedDetails = service.create(details);
        return new ResponseEntity<>(savedDetails, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ComplainMitigationDetails> update(@PathVariable int id, @RequestBody ComplainMitigationDetails details) {
        try {
            ComplainMitigationDetails updatedDetails = service.update(id, details);
            return new ResponseEntity<>(updatedDetails, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplainMitigationDetails> getById(@PathVariable int id) {
        Optional<ComplainMitigationDetails> details = service.getById(id);
        return details.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}