package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.TreeGroupMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface TreeGroupMasterRepository extends JpaRepository<TreeGroupMaster, Integer> {

}
