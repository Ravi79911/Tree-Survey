package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyAnotherDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.repository.TreeSurveyAnotherDetailsRepository;
import com.SwatiIndustries.Survey.service.TreeSurveyAnotherDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TreeSurveyAnotherDetailsServiceImpl implements TreeSurveyAnotherDetailsService {

    @Autowired
    TreeSurveyAnotherDetailsRepository treeSurveyAnotherDetailsRepository;

    @Override
    public TreeSurveyAnotherDetails createTreeSurveyAnotherDetails(TreeSurveyAnotherDetails treeSurveyAnotherDetails) {
//        if (treeSurveyAnotherDetails.getIUCNCategory() == null || treeSurveyAnotherDetails.getIUCNCategory().isEmpty()) {
//            treeSurveyAnotherDetails.setIUCNCategory("DefaultCategory");
//        }
        treeSurveyAnotherDetails.setSuspendedStatus(0);
        treeSurveyAnotherDetails.setCreatedDate(LocalDate.now());
        return treeSurveyAnotherDetailsRepository.saveAndFlush(treeSurveyAnotherDetails);
    }

    @Override
    public List<TreeSurveyAnotherDetails> getAllTreeSurveyAnotherDetails() {
        return treeSurveyAnotherDetailsRepository.findAll();
    }

    @Override
    public Optional<TreeSurveyAnotherDetails> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster) {
        return treeSurveyAnotherDetailsRepository.findByTreeSurveyMaster(treeSurveyMaster);
    }

    @Override
    public Optional<TreeSurveyAnotherDetails> findById(Integer id) {
        return treeSurveyAnotherDetailsRepository.findById(id);
    }

    @Override
    public TreeSurveyAnotherDetails patchTreeSurveyAnotherDetailsSuspendedStatus(int id, int suspendedStatus) {
        Optional<TreeSurveyAnotherDetails> patchTreeSurveyAnotherDetailsMaster = treeSurveyAnotherDetailsRepository.findById(id);
        if (patchTreeSurveyAnotherDetailsMaster.isPresent()) {
            TreeSurveyAnotherDetails existingTreeSurveyAnotherDetails = patchTreeSurveyAnotherDetailsMaster.get();
            existingTreeSurveyAnotherDetails.setSuspendedStatus(suspendedStatus);
            return treeSurveyAnotherDetailsRepository.saveAndFlush(existingTreeSurveyAnotherDetails);
        } else {
            throw new RuntimeException("TreeSurveyAnotherDetails not found with id: " + id);
        }
    }

    @Override
    public List<TreeSurveyAnotherDetails> findAllActivetreeAnotherDetails(Integer status) {
        return treeSurveyAnotherDetailsRepository.getAllBySuspendedStatus(status);
    }


}
