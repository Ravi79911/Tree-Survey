package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Tbl_tree_survey_another_detail")
public class TreeSurveyAnotherDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

//    @Column(name = "tree_survey_mas_id")
//    private int treeSurveyMasId;

    @Column(name = "economical_importance")
    private String economicalImportance;

    @Column(name = "iucns_categories")
    private String iucnsCategories;

    @Column(name = "pollution_tolerant_species")
    private Boolean pollutionTolerantSpecies;

    @Column(name = "carbon_absorbent")
    private Boolean carbonAbsorbent;

    @Column(name = "carbon_sequestration")
    private Boolean carbonSequestration;

    @Column(name = "temprature_regulating_species")
    private Boolean tempratureRegulatingSpecies;

    @Column(name = "createdby")
    private int createdBy;

    @Column(name = "createddate")
    private LocalDate createdDate;

    @Column(name = "suspendendstatus")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "tree_survey_mas_id", referencedColumnName = "id", nullable = false)
    private TreeSurveyMaster treeSurveyMaster;


}
