package com.SwatiIndustries.Survey.service;


import com.SwatiIndustries.Survey.dto.ZoneDto;
import com.SwatiIndustries.Survey.model.Zone;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ZoneService {


    List<ZoneDto> findAll();

//    List<Zone> findAllByMunicipalId(int municipal_id);

    //Zone updateZone(int id, Zone updatedZone, int updatedBy);

    //List<Zone> getAllActiveZones(int status);

    Zone findZoneById(int id);

    //Zone deleteZoneById(int zoneId, int status, int updatedBy);

    Zone createZone(Zone zone);

    //List<Zone> findAllByMunicipalId(int municipalId);

    public List<ZoneDto> getZonesByMunicipalId(int municipalId);
}
