package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.ApprovalMappingDetails;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ApprovalMappingDetailsService {

    ApprovalMappingDetails createApprovalMappingDetails(ApprovalMappingDetails details);
    ApprovalMappingDetails getApprovalMappingDetailsById(Integer id);
    ApprovalMappingDetails updateApprovalMappingDetails(Integer id, ApprovalMappingDetails newDetails);

    List<ApprovalMappingDetails> getAllActiveApprovalMappingDetailsBySuspendedStatus(Integer suspendedStatus);
}
