package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MunicipalMasterDto {

    private int id;
    private String muniCode;
    private String muniName;
    private String city;
    private String state;
    private String addressLine1;
    private String addressLine2;
    private String commisName;
    private String contactNumber;
    private String tollFreeNumber;
    private String logoFile;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private int suspendedStatus;
}
