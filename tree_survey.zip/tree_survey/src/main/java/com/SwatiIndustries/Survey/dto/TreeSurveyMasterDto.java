package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TreeSurveyMasterDto {

    private int id;
    private LocalDate surveyDate;
    private LocalDateTime surveyTime;
    private String treeUUID;
    private String girth;
    private String height;
    private int ageYear;
    private int ageMonth;
    private int ageDays;
    private String healthCondition;
    private String treeCanopy;
    private String ownershipOfLand;
    private Boolean isTreeHeritage;
    private String latitude;
    private String longitude;
    private int createdBy;
    private LocalDateTime createdDate;
    private int suspendedStatus;

    private String localName;        // Add this field for tree name
    private String scientificName;
    // Assuming you have a property like this:
    private TreeGroupMasterDto treeGroupMaster;
}
