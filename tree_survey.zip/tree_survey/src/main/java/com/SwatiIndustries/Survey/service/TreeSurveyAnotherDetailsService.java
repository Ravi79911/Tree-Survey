package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.PropertyOwnerDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyAnotherDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TreeSurveyAnotherDetailsService {

    TreeSurveyAnotherDetails createTreeSurveyAnotherDetails(TreeSurveyAnotherDetails treeSurveyAnotherDetails);

    List<TreeSurveyAnotherDetails> getAllTreeSurveyAnotherDetails();
    Optional<TreeSurveyAnotherDetails> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster);
    Optional<TreeSurveyAnotherDetails> findById(Integer id);
    TreeSurveyAnotherDetails patchTreeSurveyAnotherDetailsSuspendedStatus(int id, int suspendedStatus);

    List<TreeSurveyAnotherDetails> findAllActivetreeAnotherDetails(Integer status);
}
