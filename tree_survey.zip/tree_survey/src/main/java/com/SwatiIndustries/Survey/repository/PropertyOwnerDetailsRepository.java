package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.PropertyOwnerDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PropertyOwnerDetailsRepository extends JpaRepository<PropertyOwnerDetails, Integer> {
    List<PropertyOwnerDetails> findByTreeSurveyMasterId(int treeSurveyMasterId);
    List<PropertyOwnerDetails> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster);
}