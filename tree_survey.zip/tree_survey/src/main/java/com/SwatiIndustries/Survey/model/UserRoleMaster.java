package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "Tbl_User_Role_Master")
@Data
public class UserRoleMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "Role type is required")
    @Column(name = "role_type", nullable = false)
    private String roleType;

    @NotNull(message = "Approval status is required")
    @Column(name = "is_approved", nullable = false)
    private Boolean isApproved;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private int suspendedStatus;

    @NotNull(message = "Municipal ID is required")
    @ManyToOne
    @JoinColumn(name = "municipal_mas_id", nullable = false)
    private MunicipalMaster municipalMaster;

    @OneToMany(mappedBy = "userRoleMasterid", cascade = CascadeType.ALL)
    private Set<UserMaster> userMasters;

    @OneToMany(mappedBy = "canForwardToRole")
    private Set<ApprovalMappingDetails> approvalMappingDetailsForForward;

    @OneToMany(mappedBy = "role")
    private Set<ApprovalMappingDetails> approvalMappingDetailsForRole;

    @OneToMany(mappedBy = "canBackToRole")
    private Set<ApprovalMappingDetails> approvalMappingDetailsForBack;
}
