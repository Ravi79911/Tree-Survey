package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "tbl_user_pwd_change")
public class UserPasswordChange {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "User ID is required")
    @ManyToOne
    @JoinColumn(name = "user_mas_id", nullable = false)
    private UserMaster userMaster;

    @Column(name = "current_pwd", nullable = false)
    private String currentPwd;

    @Column(name = "last_pwd", nullable = false)
    private String lastPwd;

    @Column(name = "change_date_time", nullable = false)
    private LocalDateTime changeDateTime;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;
}
