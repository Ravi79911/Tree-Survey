package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyPhotos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface TreeSurveyPhotosRepository extends JpaRepository<TreeSurveyPhotos, Integer> {

    Optional<TreeSurveyPhotos> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster);
}
