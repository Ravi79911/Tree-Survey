package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.PropertyOwnerDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyAnotherDetails;
import com.SwatiIndustries.Survey.service.TreeSurveyAnotherDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("treeSurveyAnotherDetails")
public class TreeSurveyAnotherDetailsController {

    @Autowired
    TreeSurveyAnotherDetailsService treeSurveyAnotherDetailsService;

    @PostMapping("/createTreeSurveyAnotherDetails")
    public ResponseEntity<TreeSurveyAnotherDetails> createTreeSurveyAnother(@Valid @RequestBody TreeSurveyAnotherDetails treeSurveyAnotherDetails) {
        TreeSurveyAnotherDetails createTreeSurveyAnotherDetails = treeSurveyAnotherDetailsService.createTreeSurveyAnotherDetails(treeSurveyAnotherDetails);
        return ResponseEntity.status(HttpStatus.CREATED).body(createTreeSurveyAnotherDetails);
    }

//    @GetMapping("/getAllTreeSurveyAnotherDetails")
//    public ResponseEntity<List<TreeSurveyAnotherDetails>> getAllTreeSurveyDetailsMasters() {
//        return ResponseEntity.ok(treeSurveyAnotherDetailsService.getAllTreeSurveyAnotherDetails());
//    }

//    @PutMapping("/{id}")
//    public ResponseEntity<TreeSurveyAnotherDetails> updateStatus(@PathVariable Integer id, @Valid @RequestBody TreeSurveyAnotherDetails anotherDetails) {
//        if (treeSurveyAnotherDetailsService.findById(id).isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//        anotherDetails.setId(id);
//        TreeSurveyAnotherDetails updatedDetails = treeSurveyAnotherDetailsService.createTreeSurveyAnotherDetails(anotherDetails);
//        return ResponseEntity.ok(updatedDetails);
//    }

//    @PatchMapping("/suspendedStatus/{id}")
//    public ResponseEntity<TreeSurveyAnotherDetails> patchTreeSurveySuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
//        TreeSurveyAnotherDetails patchedTreeSurveyAnotherDetails = treeSurveyAnotherDetailsService.patchTreeSurveyAnotherDetailsSuspendedStatus(id, suspendedStatus);
//        return ResponseEntity.ok(patchedTreeSurveyAnotherDetails);
//    }

    @GetMapping("/active")
    public ResponseEntity<List<TreeSurveyAnotherDetails>> getAllActivetreeSurveyAnotherDetails(@RequestParam(required = false, defaultValue = "0") Integer status) {
        List<TreeSurveyAnotherDetails> treeSurveyAnotherDetails = treeSurveyAnotherDetailsService.findAllActivetreeAnotherDetails(status);
        return ResponseEntity.ok(treeSurveyAnotherDetails);
    }
}
