package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.TreeSurveyStatus;
import com.SwatiIndustries.Survey.repository.TreeSurveyStatusRepository;
import com.SwatiIndustries.Survey.service.TreeSurveyStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class TreeSurveyStatusserviceImpl implements TreeSurveyStatusService {

    @Autowired
    private TreeSurveyStatusRepository statusRepository;

    @Override
    public TreeSurveyStatus saveTreeSurveyStatus(TreeSurveyStatus treeSurveyStatus) {
        return statusRepository.saveAndFlush(treeSurveyStatus);
    }

    @Override
    public List<TreeSurveyStatus> findAll() {
        return statusRepository.findAll();
    }

    @Override
    public Optional<TreeSurveyStatus> findById(Integer id) {
        return statusRepository.findById(id);
    }
}
