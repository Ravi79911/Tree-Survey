package com.SwatiIndustries.Survey.service;


import com.SwatiIndustries.Survey.dto.MunicipalMasterDto;
import com.SwatiIndustries.Survey.model.MunicipalMaster;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public interface MunicipalMasterService {

    MunicipalMaster createMunicipalMaster(MunicipalMaster municipalMaster, MultipartFile logoFile);
    List<MunicipalMasterDto> getAllMunicipalMaster();

    Optional<MunicipalMaster> getMunicipalMasterById(int id);
    List<MunicipalMaster> getMunicipalMasterByMuniName(String muniName);
    MunicipalMaster updateMunicipalMasterById(int id, MunicipalMaster municipalMaster);
    MunicipalMaster patchMunicipalMasterSuspendedStatus(int id, int suspendedStatus);
    Resource loadLogo(int id) throws IOException;

    List<MunicipalMaster> findAllActiveMunicipalMaster(Integer status);
}