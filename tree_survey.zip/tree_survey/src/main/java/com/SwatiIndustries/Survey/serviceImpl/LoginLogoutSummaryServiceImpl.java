package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.LoginLogoutSummary;
import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.repository.LoginLogoutSummaryRepository;
import com.SwatiIndustries.Survey.service.LoginLogoutSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginLogoutSummaryServiceImpl implements LoginLogoutSummaryService {

    @Autowired
    private LoginLogoutSummaryRepository loginLogoutSummaryRepository;

    @Override
    public LoginLogoutSummary saveLoginLogoutSummary(LoginLogoutSummary loginLogoutSummary) {
        return loginLogoutSummaryRepository.save(loginLogoutSummary);
    }

//    @Override
//    public Optional<LoginLogoutSummary> getUserMasterId(UserMaster userMaster) {
//        return loginLogoutSummaryRepository.findByUserMaster(userMaster); // Update method call
//    }
}
