package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.CuttingAndPruningMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface CuttingAndPruningMasterRepository extends JpaRepository<CuttingAndPruningMaster, Integer> {
    List<CuttingAndPruningMaster> findBySuspendedStatus(Integer status);
}