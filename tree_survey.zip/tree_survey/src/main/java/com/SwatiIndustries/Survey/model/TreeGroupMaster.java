package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_tree_group_master")
public class TreeGroupMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "Tree_Name")
    private String treeName;

    @Column(name = "Scientific_Name")
    private String scientificName;
}
