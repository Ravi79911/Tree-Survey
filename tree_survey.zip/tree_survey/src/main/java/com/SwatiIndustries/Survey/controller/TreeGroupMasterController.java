package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.TreeGroupMaster;
import com.SwatiIndustries.Survey.service.TreeGroupMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/treeGroupMaster")
public class TreeGroupMasterController {

    @Autowired
    TreeGroupMasterService treeGroupMasterService;

    @GetMapping("/getAllTreeGroupMaster")
    public ResponseEntity<List<TreeGroupMaster>> getAllGroupMasterMasters() {
        return ResponseEntity.ok(treeGroupMasterService.getAllTreeGroupMaster());
    }


}
