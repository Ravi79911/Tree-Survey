package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.service.UserInfoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/userInfo")
public class UserInfoController {

    @Autowired
    private UserInfoService userInfoService;

    @PostMapping("/create")
    public ResponseEntity<UserInfo> createUserInfo(@Valid @RequestBody UserInfo userInfo) {
        UserInfo savedUserInfo = userInfoService.saveUserInfo(userInfo);
        return new ResponseEntity<>(savedUserInfo, HttpStatus.CREATED);
    }


    @GetMapping("/All-ActiveUsersInfo")
    public ResponseEntity<List<UserInfo>> getUsersBySuspendedStatus(@RequestParam (required = false, defaultValue = "0")Integer suspendedStatus) {
        List<UserInfo> userInfoList = userInfoService.getAllActiveUsersBySuspendedStatus(suspendedStatus);
        return ResponseEntity.ok(userInfoList);
    }

    @GetMapping("/findByUserId")
    public ResponseEntity<UserInfo> getUserInfoById(@RequestParam Integer userMasterId) {
        UserMaster userMaster = new UserMaster();
        userMaster.setId(userMasterId); // Set ID to userMaster
        Optional<UserInfo> userInfo = userInfoService.getUserMasterId(userMaster); // Pass UserMaster object
        return userInfo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

}
