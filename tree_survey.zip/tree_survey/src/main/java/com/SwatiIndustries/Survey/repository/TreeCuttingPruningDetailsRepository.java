package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.TreeCuttingPruningDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;

@EnableJpaRepositories
public interface TreeCuttingPruningDetailsRepository extends JpaRepository<TreeCuttingPruningDetails, Integer> {

    @Query("SELECT t FROM TreeCuttingPruningDetails t WHERE t.cuttingAndPruningMaster.id = :cuttingAndPruningMasterId")
    List<TreeCuttingPruningDetails> findByCuttingAndPruningMasterId(@Param("cuttingAndPruningMasterId") int cuttingAndPruningMasterId);
}
