package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.TreeSurveyPhotos;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public interface TreeSurveyPhotosService {

    TreeSurveyPhotos createTreeSurveyPhotos(TreeSurveyPhotos treeSurveyPhotos, MultipartFile photoTree1, MultipartFile photoTree2,
                                            MultipartFile photoTree3, MultipartFile photoLeaf, MultipartFile photoTrunk,
                                            MultipartFile photoFlower, MultipartFile photoFruits, MultipartFile photoOthers);

    List<TreeSurveyPhotos> getAllTreeSurveyPhotos();

    Resource loadPhotos(int id) throws IOException;

}
