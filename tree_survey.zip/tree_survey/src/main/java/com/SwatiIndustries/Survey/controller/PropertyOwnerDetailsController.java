package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.model.PropertyOwnerDetails;
import com.SwatiIndustries.Survey.service.PropertyOwnerDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/property-owner-details")
@Validated
public class PropertyOwnerDetailsController {

    private final PropertyOwnerDetailsService propertyOwnerDetailsService;

    @Autowired
    public PropertyOwnerDetailsController(PropertyOwnerDetailsService propertyOwnerDetailsService) {
        this.propertyOwnerDetailsService = propertyOwnerDetailsService;
    }

    @PostMapping("/save")
    public ResponseEntity<PropertyOwnerDetails> saveOwnerDetails(@Valid @RequestBody PropertyOwnerDetails propertyOwnerDetails) {
        PropertyOwnerDetails savedDetails = propertyOwnerDetailsService.savePropertyOwnerDetails(propertyOwnerDetails);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedDetails);
    }

    @GetMapping("{treeSurveyMasterId}")
    public ResponseEntity<List<PropertyOwnerDetails>> getPropertyOwnerDetailsByTreeSurveyMasterId(@PathVariable int treeSurveyMasterId) {
        List<PropertyOwnerDetails> propertyOwnerDetails = propertyOwnerDetailsService.getPropertyOwnerDetailsByTreeSurveyMasterId(treeSurveyMasterId);
        return ResponseEntity.ok(propertyOwnerDetails);
    }

//    @PutMapping("/{id}")
//    public ResponseEntity<PropertyOwnerDetails> updateStatus(@PathVariable Integer id, @Valid @RequestBody PropertyOwnerDetails details) {
//        if (propertyOwnerDetailsService.findById(id).isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//        details.setId(id);
//       PropertyOwnerDetails updatedDetails = propertyOwnerDetailsService.savePropertyOwnerDetails(details);
//        return ResponseEntity.ok(updatedDetails);
//    }


//    @PatchMapping("/PropertyOwner/suspendedStatus/{id}")
//    public ResponseEntity<PropertyOwnerDetails>patchPropertyOwnerDetailsSuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
//        PropertyOwnerDetails patchedPropertyOwnerDetails = propertyOwnerDetailsService.patchPropertyOwnerDetailsSuspendedStatus(id, suspendedStatus);
//        return ResponseEntity.ok(patchedPropertyOwnerDetails);
//    }
}
