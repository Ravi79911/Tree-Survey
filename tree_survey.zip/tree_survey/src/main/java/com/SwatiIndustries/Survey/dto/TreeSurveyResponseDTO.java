package com.SwatiIndustries.Survey.dto;

import lombok.Data;

import java.util.List;

@Data
public class TreeSurveyResponseDTO {
    private TreeSurveyMasterDto treeSurveyMaster;
    private List<PropertyOwnerDetailsDto> propertyOwnerDetails;
    private TreeSurveyAnotherDetailsDto treeSurveyAnotherDetails;
    private TreeSurveyPhotosDto treeSurveyPhotos;
    private MunicipalMasterDto municipalMaster;
    private ZoneDto zone;
    private ZoneWardDto zoneWard;
}
