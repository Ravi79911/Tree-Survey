package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.model.ApprovalMappingDetails;
import com.SwatiIndustries.Survey.model.LoginLogoutSummary;
import com.SwatiIndustries.Survey.service.ApprovalMappingDetailsService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/approvalMappingDetails")
public class ApprovalMappingDetailsController {

    @Autowired
    private ApprovalMappingDetailsService approvalMappingDetailsService;

    // POST API to create a new ApprovalMappingDetails
    @PostMapping("/create")
    public ResponseEntity<ApprovalMappingDetails> createApprovalMappingDetails(
            @RequestBody ApprovalMappingDetails details) {
        ApprovalMappingDetails createdDetails = approvalMappingDetailsService.createApprovalMappingDetails(details);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDetails);
    }

    // GET BY ID API to retrieve ApprovalMappingDetails by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApprovalMappingDetails> getApprovalMappingDetailsById(@PathVariable("id") Integer id) {
        ApprovalMappingDetails details = approvalMappingDetailsService.getApprovalMappingDetailsById(id);
        return ResponseEntity.ok(details);
    }

    // PUT API to update an existing ApprovalMappingDetails
    @PutMapping("/{id}")
    public ResponseEntity<ApprovalMappingDetails> updateApprovalMappingDetails(
            @PathVariable("id") Integer id,
            @RequestBody ApprovalMappingDetails newDetails) {
        ApprovalMappingDetails updatedDetails = approvalMappingDetailsService.updateApprovalMappingDetails(id, newDetails);
        return ResponseEntity.ok(updatedDetails);
    }

    @GetMapping("/All-ActiveApprovalMappingDetails")
    public ResponseEntity<List<ApprovalMappingDetails>> getApprovalMappingDetailsBySuspendedStatus(@RequestParam (required = false, defaultValue = "0")Integer suspendedStatus) {
        List<ApprovalMappingDetails> approvalMappingDetailsList = approvalMappingDetailsService.getAllActiveApprovalMappingDetailsBySuspendedStatus(suspendedStatus);
        return ResponseEntity.ok(approvalMappingDetailsList);
    }
}
