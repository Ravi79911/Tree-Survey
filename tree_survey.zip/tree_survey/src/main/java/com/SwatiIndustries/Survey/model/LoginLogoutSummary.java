package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "tbl_login_logout_summary")
public class LoginLogoutSummary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @NotNull(message = "User ID is required")
    @ManyToOne
    @JoinColumn(name = "user_mas_id", nullable = false)
    private UserMaster userMaster;

    @NotNull(message = "Action cannot be null")
    @Column(name = "Action", nullable = false, length = 50)
    private String action;

    @Column(name = "login_time")
    private LocalDateTime loginTime;

    @Column(name = "logout_time")
    private LocalDateTime logoutTime;

}
