package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.dto.*;
import com.SwatiIndustries.Survey.exception.ResourceNotFoundException;
import com.SwatiIndustries.Survey.model.*;
import com.SwatiIndustries.Survey.repository.PropertyOwnerDetailsRepository;
import com.SwatiIndustries.Survey.repository.TreeSurveyAnotherDetailsRepository;
import com.SwatiIndustries.Survey.repository.TreeSurveyMasterRepository;
import com.SwatiIndustries.Survey.repository.TreeSurveyPhotosRepository;
import com.SwatiIndustries.Survey.service.TreeSurveyMasterService;
import com.SwatiIndustries.Survey.utils.TreeUuidAutomaticGenerate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TreeSurveyMasterServiceImpl implements TreeSurveyMasterService {

    @Autowired
    TreeSurveyMasterRepository treeSurveyMasterRepository;

    @Autowired
    private PropertyOwnerDetailsRepository propertyOwnerDetailsRepository;

    @Autowired
    private TreeSurveyAnotherDetailsRepository treeSurveyAnotherDetailsRepository;

    @Autowired
    private TreeSurveyPhotosRepository treeSurveyPhotosRepository;

    @Override
    public TreeSurveyMaster createTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster) {
        String generatedApplicationNumber = TreeUuidAutomaticGenerate.generateApplicationNo();
        treeSurveyMaster.setTreeUUID(generatedApplicationNumber);
        treeSurveyMaster.setSuspendedStatus(0);
        treeSurveyMaster.setCreatedDate(LocalDateTime.now());
        treeSurveyMaster.setSurveyDate(LocalDate.now());
//        if (treeSurveyMaster.getCreatedDate() == null) {
//            treeSurveyMaster.setCreatedDate(LocalDateTime.now());
//            treeSurveyMaster.setSurveyDate(LocalDate.now());
//            treeSurveyMaster.setSurveyTime(LocalDateTime.now());
//        }
        return treeSurveyMasterRepository.saveAndFlush(treeSurveyMaster);
    }

    @Override
    public List<TreeSurveyMaster> getAllTreeSurveyMasters() {
        return treeSurveyMasterRepository.findAll();
    }


    public TreeSurveyResponseDTO getTreeSurveyDetailsByTreeUUID(String treeUUID) {
        TreeSurveyMaster treeSurveyMaster = treeSurveyMasterRepository.findByTreeUUID(treeUUID)
                .orElseThrow(() -> new RuntimeException("TreeSurveyMaster not found for treeUUID: " + treeUUID));

        TreeSurveyResponseDTO response = new TreeSurveyResponseDTO();

        // Set TreeSurveyMasterDTO
        TreeSurveyMasterDto masterDTO = new TreeSurveyMasterDto();
        masterDTO.setId(treeSurveyMaster.getId());
        masterDTO.setSurveyDate(treeSurveyMaster.getSurveyDate());
        masterDTO.setSurveyTime(treeSurveyMaster.getSurveyTime());
        masterDTO.setTreeUUID(treeSurveyMaster.getTreeUUID());
        masterDTO.setGirth(treeSurveyMaster.getGirth());
        masterDTO.setHeight(treeSurveyMaster.getHeight());
        masterDTO.setAgeYear(treeSurveyMaster.getAgeYear());
        masterDTO.setAgeMonth(treeSurveyMaster.getAgeMonth());
        masterDTO.setAgeDays(treeSurveyMaster.getAgeDays());
        masterDTO.setHealthCondition(treeSurveyMaster.getHealthCondition());
        masterDTO.setTreeCanopy(treeSurveyMaster.getTreeCanopy());
        masterDTO.setOwnershipOfLand(treeSurveyMaster.getOwnershipOfLand());
        masterDTO.setIsTreeHeritage(treeSurveyMaster.getIsTreeHeritage());
        masterDTO.setLatitude(treeSurveyMaster.getLatitude());
        masterDTO.setLongitude(treeSurveyMaster.getLongitude());
        masterDTO.setCreatedBy(treeSurveyMaster.getCreatedBy());
        masterDTO.setCreatedDate(treeSurveyMaster.getCreatedDate());
        masterDTO.setSuspendedStatus(treeSurveyMaster.getSuspendedStatus());

        // Set TreeGroupMasterDTO
        if (treeSurveyMaster.getTreeGroupMaster() != null) {
            TreeGroupMasterDto groupMasterDTO = new TreeGroupMasterDto();
            groupMasterDTO.setId(treeSurveyMaster.getTreeGroupMaster().getId());
            groupMasterDTO.setTreeName(treeSurveyMaster.getTreeGroupMaster().getTreeName());
            groupMasterDTO.setScientificName(treeSurveyMaster.getTreeGroupMaster().getScientificName());
            masterDTO.setTreeGroupMaster(groupMasterDTO); // Note: Update to match the property name
        }
        response.setTreeSurveyMaster(masterDTO);

        // Set MunicipalMasterDTO
        if (treeSurveyMaster.getMunicipalMaster() != null) {
            MunicipalMasterDto municipalMasterDTO = new MunicipalMasterDto();
            municipalMasterDTO.setId(treeSurveyMaster.getMunicipalMaster().getId());
            municipalMasterDTO.setMuniName(treeSurveyMaster.getMunicipalMaster().getMuniName());
            // Set other MunicipalMaster fields
            response.setMunicipalMaster(municipalMasterDTO);
        }

        // Set ZoneDTO
        if (treeSurveyMaster.getZone() != null) {
            ZoneDto zoneDTO = new ZoneDto();
            zoneDTO.setId(treeSurveyMaster.getZone().getId());
            zoneDTO.setZoneName(treeSurveyMaster.getZone().getZoneName());
            // Set other Zone fields
            response.setZone(zoneDTO);
        }

        // Set ZoneWardDTO
        if (treeSurveyMaster.getZoneWard() != null) {
            ZoneWardDto zoneWardDTO = new ZoneWardDto();
            zoneWardDTO.setId(treeSurveyMaster.getZoneWard().getId());
            zoneWardDTO.setWardNo(treeSurveyMaster.getZoneWard().getWardNo());
            // Set other ZoneWard fields
            response.setZoneWard(zoneWardDTO);
        }


        // Set PropertyOwnerDetailsDTO list
        List<PropertyOwnerDetails> owners = propertyOwnerDetailsRepository.findByTreeSurveyMaster(treeSurveyMaster);
        List<PropertyOwnerDetailsDto> ownerDTOs = owners.stream().map(owner -> {
            PropertyOwnerDetailsDto ownerDTO = new PropertyOwnerDetailsDto();
            ownerDTO.setId(owner.getId());
            ownerDTO.setOwnerName(owner.getOwnerName());
            ownerDTO.setHoldingNo(owner.getHoldingNo());
            ownerDTO.setOwnerAddress(owner.getOwnerAddress());
            ownerDTO.setContactNumber(owner.getContactNumber());
            ownerDTO.setEmailId(owner.getEmailId());
            ownerDTO.setAadharNo(owner.getAadharNo());
            ownerDTO.setCreatedBy(owner.getCreatedBy());
            ownerDTO.setCreatedDate(owner.getCreatedDate());
            ownerDTO.setSuspendedStatus(owner.getSuspendedStatus());
            return ownerDTO;
        }).toList();
        response.setPropertyOwnerDetails(ownerDTOs);

        // Set TreeSurveyAnotherDetailsDTO
        TreeSurveyAnotherDetails anotherDetails = treeSurveyAnotherDetailsRepository.findByTreeSurveyMaster(treeSurveyMaster)
                .orElse(null);
        if (anotherDetails != null) {
            TreeSurveyAnotherDetailsDto anotherDetailsDTO = new TreeSurveyAnotherDetailsDto();
            anotherDetailsDTO.setId(anotherDetails.getId());
            anotherDetailsDTO.setEconomicalImportance(anotherDetails.getEconomicalImportance());
            anotherDetailsDTO.setIUCN_category(anotherDetails.getIucnsCategories());
            anotherDetailsDTO.setPollutionTolerantSpecies(anotherDetails.getPollutionTolerantSpecies());
            anotherDetailsDTO.setCarbonAbsorbent(anotherDetails.getCarbonAbsorbent());
            anotherDetailsDTO.setCarbonSequestration(anotherDetails.getCarbonSequestration());
            anotherDetailsDTO.setTempratureRegulatingSpecies(anotherDetails.getTempratureRegulatingSpecies());
            anotherDetailsDTO.setCreatedBy(anotherDetails.getCreatedBy());
            anotherDetailsDTO.setCreatedDate(anotherDetails.getCreatedDate());
            anotherDetailsDTO.setSuspendedStatus(anotherDetails.getSuspendedStatus());
            response.setTreeSurveyAnotherDetails(anotherDetailsDTO);
        }

        // Set TreeSurveyPhotosDTO
        TreeSurveyPhotos photos = treeSurveyPhotosRepository.findByTreeSurveyMaster(treeSurveyMaster)
                .orElse(null);
        if (photos != null) {
            TreeSurveyPhotosDto photosDTO = new TreeSurveyPhotosDto();
            photosDTO.setId(photos.getId());
            photosDTO.setPhotoTree1(photos.getPhotoTree1());
            photosDTO.setPhotoTree2(photos.getPhotoTree2());
            photosDTO.setPhotoTree3(photos.getPhotoTree3());
            photosDTO.setIsIdentified(photos.getIsIdentified());
            photosDTO.setPhotoLeaf(photos.getPhotoLeaf());
            photosDTO.setPhotoTrunk(photos.getPhotoTrunk());
            photosDTO.setPhotoFlower(photos.getPhotoFlower());
            photosDTO.setPhotoFruits(photos.getPhotoFruits());
            photosDTO.setPhotoOthers(photos.getPhotoOthers());
            photosDTO.setCreatedBy(photos.getCreatedBy());
            photosDTO.setCreatedDate(photos.getCreatedDate());
            photosDTO.setSuspendedStatus(photos.getSuspendedStatus());
            response.setTreeSurveyPhotos(photosDTO);
        }

        return response;
    }

    @Override
    public Optional<TreeSurveyMaster> findById(Integer id) {
        return treeSurveyMasterRepository.findById(id);
    }

    @Override
    public TreeSurveyMaster patchTreeSurveyMasterSuspendedStatus(int id, int suspendedStatus) {
        Optional<TreeSurveyMaster> patchTreeSurveyMaster = treeSurveyMasterRepository.findById(id);
        if (patchTreeSurveyMaster.isPresent()) {
            TreeSurveyMaster existingTreeSurveyMaster = patchTreeSurveyMaster.get();
            existingTreeSurveyMaster.setSuspendedStatus(suspendedStatus);
            return treeSurveyMasterRepository.saveAndFlush(existingTreeSurveyMaster);
        } else {
            throw new RuntimeException("Tree Survey Master not found with id: " + id);
        }
    }

    @Override
    public List<TreeSurveyMaster> findByTreeName(String treeName) {
        return treeSurveyMasterRepository.findByTreeName(treeName);
    }

    public List<String> getTreeNamesByZoneWardId(int zoneWardId) {
        List<TreeSurveyMaster> treeSurveys = treeSurveyMasterRepository.findByZoneWardId(zoneWardId);
        return treeSurveys.stream()
                .map(TreeSurveyMaster::getLocalName)
                .collect(Collectors.toList());
    }

    public List<TreeSurveyMasterDto> getTreeSurveysByWhereCondition(int municipalId, int zoneId, int zoneWardId) {
        List<TreeSurveyMaster> treeSurveyMasters = treeSurveyMasterRepository.findByMunicipalMasterIdAndZoneIdAndZoneWardId(municipalId, zoneId, zoneWardId);
        if (treeSurveyMasters.isEmpty()) {
            return Collections.emptyList(); // or throw an exception
        }
        return treeSurveyMasters.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private TreeSurveyMasterDto convertToDto(TreeSurveyMaster entity) {
        TreeSurveyMasterDto dto = new TreeSurveyMasterDto();
        dto.setId(entity.getId());
        dto.setSurveyDate(entity.getSurveyDate());
        dto.setSurveyTime(entity.getSurveyTime());
        dto.setTreeUUID(entity.getTreeUUID());
        dto.setGirth(entity.getGirth());
        dto.setHeight(entity.getHeight());
        dto.setAgeYear(entity.getAgeYear());
        dto.setAgeMonth(entity.getAgeMonth());
        dto.setAgeDays(entity.getAgeDays());
        dto.setHealthCondition(entity.getHealthCondition());
        dto.setTreeCanopy(entity.getTreeCanopy());
        dto.setOwnershipOfLand(entity.getOwnershipOfLand());
        dto.setIsTreeHeritage(entity.getIsTreeHeritage());
        dto.setLatitude(entity.getLatitude());
        dto.setLongitude(entity.getLongitude());
        dto.setCreatedBy(entity.getCreatedBy());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setSuspendedStatus(entity.getSuspendedStatus());
        dto.setTreeGroupMaster(new TreeGroupMasterDto(
                entity.getTreeGroupMaster().getId(),           // This is the treeNameId
                entity.getTreeGroupMaster().getTreeName(),
                entity.getTreeGroupMaster().getScientificName()
        ));
        return dto;
    }

    @Override
    public List<TreeSurveyMaster> getTreeSurveyMastersByOwnershipOfLandAndFilters(
            String ownershipOfLand, int municipalId, int zoneId, int zoneWardId, String treeName) {
        return treeSurveyMasterRepository.findByOwnershipOfLandAndMunicipalIdAndZoneIdAndZoneWardIdAndTreeName(
                ownershipOfLand, municipalId, zoneId, zoneWardId, treeName);
    }

    @Override
    public TreeSurveyMaster updateTreeSurvey(int id, TreeSurveyMaster treeSurveyMasterDetails) {
        TreeSurveyMaster existingTreeSurvey = treeSurveyMasterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TreeSurveyMaster", "id", id));

        // Update only the provided fields
        if (treeSurveyMasterDetails.getSurveyDate() != null) {
            existingTreeSurvey.setSurveyDate(treeSurveyMasterDetails.getSurveyDate());
        }
        if (treeSurveyMasterDetails.getSurveyTime() != null) {
            existingTreeSurvey.setSurveyTime(treeSurveyMasterDetails.getSurveyTime());
        }
        if (treeSurveyMasterDetails.getTreeUUID() != null) {
            existingTreeSurvey.setTreeUUID(treeSurveyMasterDetails.getTreeUUID());
        }
        if (treeSurveyMasterDetails.getGirth() != null) {
            existingTreeSurvey.setGirth(treeSurveyMasterDetails.getGirth());
        }
        if (treeSurveyMasterDetails.getHeight() != null) {
            existingTreeSurvey.setHeight(treeSurveyMasterDetails.getHeight());
        }
        if (treeSurveyMasterDetails.getAgeYear() != 0) {
            existingTreeSurvey.setAgeYear(treeSurveyMasterDetails.getAgeYear());
        }
        if (treeSurveyMasterDetails.getAgeMonth() != 0) {
            existingTreeSurvey.setAgeMonth(treeSurveyMasterDetails.getAgeMonth());
        }
        if (treeSurveyMasterDetails.getAgeDays() != 0) {
            existingTreeSurvey.setAgeDays(treeSurveyMasterDetails.getAgeDays());
        }
        if (treeSurveyMasterDetails.getHealthCondition() != null) {
            existingTreeSurvey.setHealthCondition(treeSurveyMasterDetails.getHealthCondition());
        }
        if (treeSurveyMasterDetails.getTreeCanopy() != null) {
            existingTreeSurvey.setTreeCanopy(treeSurveyMasterDetails.getTreeCanopy());
        }
        if (treeSurveyMasterDetails.getOwnershipOfLand() != null) {
            existingTreeSurvey.setOwnershipOfLand(treeSurveyMasterDetails.getOwnershipOfLand());
        }
        if (treeSurveyMasterDetails.getIsTreeHeritage() != null) {
            existingTreeSurvey.setIsTreeHeritage(treeSurveyMasterDetails.getIsTreeHeritage());
        }
        if (treeSurveyMasterDetails.getLatitude() != null) {
            existingTreeSurvey.setLatitude(treeSurveyMasterDetails.getLatitude());
        }
        if (treeSurveyMasterDetails.getLongitude() != null) {
            existingTreeSurvey.setLongitude(treeSurveyMasterDetails.getLongitude());
        }
        if (treeSurveyMasterDetails.getCreatedBy() != 0) {
            existingTreeSurvey.setCreatedBy(treeSurveyMasterDetails.getCreatedBy());
        }
        if (treeSurveyMasterDetails.getCreatedDate() != null) {
            existingTreeSurvey.setCreatedDate(treeSurveyMasterDetails.getCreatedDate());
        }
        if (treeSurveyMasterDetails.getSuspendedStatus() != 0) {
            existingTreeSurvey.setSuspendedStatus(treeSurveyMasterDetails.getSuspendedStatus());
        }
        if (treeSurveyMasterDetails.getTreeGroupMaster() != null) {
            existingTreeSurvey.setTreeGroupMaster(treeSurveyMasterDetails.getTreeGroupMaster());
        }
        if (treeSurveyMasterDetails.getMunicipalMaster() != null) {
            existingTreeSurvey.setMunicipalMaster(treeSurveyMasterDetails.getMunicipalMaster());
        }
        if (treeSurveyMasterDetails.getZone() != null) {
            existingTreeSurvey.setZone(treeSurveyMasterDetails.getZone());
        }
        if (treeSurveyMasterDetails.getZoneWard() != null) {
            existingTreeSurvey.setZoneWard(treeSurveyMasterDetails.getZoneWard());
        }

        // Handle OneToMany relationship for TreeCuttingPruningDetails
        if (treeSurveyMasterDetails.getTreeCuttingPruningDetails() != null) {
            existingTreeSurvey.getTreeCuttingPruningDetails().clear();
            existingTreeSurvey.getTreeCuttingPruningDetails().addAll(treeSurveyMasterDetails.getTreeCuttingPruningDetails());
            for (TreeCuttingPruningDetails detail : existingTreeSurvey.getTreeCuttingPruningDetails()) {
                detail.setTreeSurveyMaster(existingTreeSurvey);
            }
        }

        return treeSurveyMasterRepository.save(existingTreeSurvey);
    }

    @Override
    public List<TreeSurveyMaster> findAllActiveTreeSurveyMaster(Integer status) {
        return treeSurveyMasterRepository.findBySuspendedStatus(status);
    }


}







