package com.SwatiIndustries.Survey.repository;


import com.SwatiIndustries.Survey.model.UserMasterDemo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserMasterDemoRepository extends JpaRepository<UserMasterDemo, Long> {
    Optional<UserMasterDemo> findByUsername(String username);
}
