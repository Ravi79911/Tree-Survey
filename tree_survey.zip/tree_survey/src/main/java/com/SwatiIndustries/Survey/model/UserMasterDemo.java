package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.Date;

@Entity
@Table(name = "Tbl_User_masters")
@Data
public class UserMasterDemo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank(message = "Username is mandatory")
    @Column(name = "user_name", nullable = false)
    private String username;

    @NotBlank(message = "Password is mandatory")
    @Size(min = 8, message = "Password must be at least 8 characters long")
    @Column(name = "password", nullable = false)
    private String password;


    @Column(name = "photo")
    private String photo;

    @NotBlank(message = "Name is mandatory")
    @Column(name = "name_off", nullable = false)
    private String nameOff;

    @NotBlank(message = "Email ID is mandatory")
    @Email(message = "Email ID should be valid")
    @Column(name = "email_id", nullable = false)
    private String emailId;

    @NotBlank(message = "Mobile number is mandatory")
    @Column(name = "mobile_no", nullable = false)
    private String mobileNo;

    @NotBlank(message = "Department is mandatory")
    @Size(max = 50, message = "Department should not exceed 50 characters")
    @Column(name = "department")
    private String department;

    @NotBlank(message = "Aadhar number is mandatory")
    @Column(name = "aadhar_no")
    private String aadharNo;

    @NotNull(message = "Created date is mandatory")
    @PastOrPresent(message = "Created date must be in the past or present")
    @Column(name = "created_Date", nullable = false)
    private Date createdDate;

    @Min(value = 0, message = "Suspended status must be 0 or higher")
    @Column(name = "suspended_status", nullable = false)
    private int suspendedStatus;
}

