package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.UserRoleMaster;
import com.SwatiIndustries.Survey.repository.UserRoleMasterRepository;
import com.SwatiIndustries.Survey.service.UserRoleMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UserRoleMasterServiceImpl implements UserRoleMasterService {

    @Autowired
    private UserRoleMasterRepository userRoleMasterRepository;


    @Override
    public UserRoleMaster saveUserRoleMaster(UserRoleMaster userRoleMaster) {
        // Set the createdDate and updateDate if they are not already set
        if (userRoleMaster.getCreatedDate() == null) {
            userRoleMaster.setCreatedDate(LocalDateTime.now());
        }
        userRoleMaster.setUpdatedDate(LocalDateTime.now());
        userRoleMaster.setSuspendedStatus(0);
        return userRoleMasterRepository.save(userRoleMaster);
    }

    @Override
    public List<UserRoleMaster> findAllActiveUserRoleMaster(Integer status) {
        return userRoleMasterRepository.findBySuspendedStatus(status);
    }

}
