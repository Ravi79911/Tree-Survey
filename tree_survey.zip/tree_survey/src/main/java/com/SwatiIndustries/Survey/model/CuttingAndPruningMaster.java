package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_cutting_and_pruning_masters")
public class CuttingAndPruningMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "apply_from")
    private String applyFrom;

    @NotBlank(message = "Apply for field cannot be blank")
    @Column(name = "apply_for")
    private String applyFor;

    @NotBlank(message = "Applicant name cannot be blank")
    @Column(name = "applicant_name")
    private String applicantName;

    @Pattern(regexp = "^\\+?[0-9. ()-]{7,25}$", message = "Invalid mobile number")
    @Column(name = "mobile_no")
    private String mobileNo;

    @Email(message = "Invalid email address")
    @Column(name = "email_id")
    private String emailId;

    @NotBlank(message = "Address cannot be blank")
    @Column(name = "address")
    private String address;

    @Column(name = "designation")
    private String designation;

    @Column(name = "department")
    private String department;

    @NotBlank(message = "Purpose cannot be blank")
    @Column(name = "purpose")
    private String purpose;

    @Column(name = "request_remarks")
    private String requestRemarks;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @NotNull(message = "Suspended status is required")
    @Column(name = "suspendedstatus")
    private int suspendedStatus;

    @NotNull(message = "Municipal Master is required")
    @ManyToOne
    @JoinColumn(name = "Muncipal_id", nullable = false)  // Update to correct column name
    private MunicipalMaster municipalMaster;

    @NotNull(message = "Zone is required")
    @ManyToOne
    @JoinColumn(name = "zone_id", nullable = false)
    private Zone zone;

    @NotNull(message = "Zone Ward is required")
    @ManyToOne
    @JoinColumn(name = "ward_id", nullable = false)
    private ZoneWard zoneWard;

    @OneToMany(mappedBy = "cuttingAndPruningMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<TreeCuttingPruningDetails> treeCuttingPruningDetails;

    @OneToMany(mappedBy = "cuttingAndPruningMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ComplainMitigationDetails> complainMitigationDetails;

    // Add other fields and methods as needed
}