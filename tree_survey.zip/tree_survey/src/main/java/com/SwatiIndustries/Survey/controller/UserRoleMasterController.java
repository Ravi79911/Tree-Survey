package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.UserRoleMaster;
import com.SwatiIndustries.Survey.service.UserRoleMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/UserRoleMaster")
@CrossOrigin
public class UserRoleMasterController {

    @Autowired
    private UserRoleMasterService userRoleMasterService;

    @PostMapping("/create")
    public ResponseEntity<UserRoleMaster> createUserRoleMaster(@Valid @RequestBody UserRoleMaster userRoleMaster) {
        UserRoleMaster savedUserRoleMaster = userRoleMasterService.saveUserRoleMaster(userRoleMaster);
        return new ResponseEntity<>(savedUserRoleMaster, HttpStatus.CREATED);
    }

    @GetMapping("/active")
    public ResponseEntity<List<UserRoleMaster>> getAllActiveMunicipalMaster(@RequestParam(required = false, defaultValue = "0") Integer status){
        List<UserRoleMaster> userRoleMasters=userRoleMasterService.findAllActiveUserRoleMaster(status);
        return ResponseEntity.ok(userRoleMasters);

    }
}
