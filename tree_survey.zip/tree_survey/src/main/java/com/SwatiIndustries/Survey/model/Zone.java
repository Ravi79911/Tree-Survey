package com.SwatiIndustries.Survey.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_zone_master")
public class Zone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotBlank(message = "Zone name is required")
    @Column(name = "zone_name")
    private String zoneName;

    @NotNull(message = "Created by is required")
    @Column(name = "createdby")
    private int createdBy;

    @Column(name = "createddate")
    private LocalDateTime createdDate;

    @NotNull(message = "Updated by is required")
    @Column(name = "updatedby")
    private int updatedBy;

    @Column(name = "updateddate")
    private LocalDateTime updatedDate;

    @NotNull(message = "Suspended status is required")
    @Column(name = "suspendedstatus")
    private int suspendedStatus;

//    @NotNull(message = "municipal id is required")
//    @Column(name = "municipal_id")
//    private int municipalId;

    @NotNull(message = "Municipal ID is required")
    @ManyToOne
    @JoinColumn(name = "municipal_id", nullable = false)
    private MunicipalMaster municipalMaster;

    @OneToMany(mappedBy = "zone", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ZoneWard> zoneWards;

    @OneToMany(mappedBy = "zone", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<CuttingAndPruningMaster> cuttingAndPruningMasters;

    @OneToMany(mappedBy = "zone", cascade = CascadeType.ALL)
    private Set<UserInfo> userInfo;


}
