package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.dto.MunicipalMasterDto;
import com.SwatiIndustries.Survey.model.CuttingAndPruningMaster;
import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.service.MunicipalMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class MunicipalMasterController {

    @Autowired
    MunicipalMasterService municipalMasterService;

//    @PostMapping("/createMunicipalMaster")
//    public ResponseEntity<MunicipalMaster> createMunicipalMaster(@Valid @RequestBody MunicipalMaster municipalMaster) {
//        MunicipalMaster createMunicipal = municipalMasterService.createMunicipalMaster(municipalMaster);
//        return ResponseEntity.status(HttpStatus.CREATED).body(createMunicipal);
//    }

    @PostMapping("/createMunicipalMaster")
    public ResponseEntity<Object> createMunicipalMaster(
            @Valid @RequestParam(value = "logoFile", required = false) MultipartFile logoFile,
            @RequestParam("muniCode") String muniCode,
            @RequestParam("muniName") String muniName,
            @RequestParam("city") String city,
            @RequestParam("state") String state,
            @RequestParam("addressLine1") String addressLine1,
            @RequestParam("addressLine2") String addressLine2,
            @RequestParam("commisName") String commisName,
            @RequestParam("contactNumber") String contactNumber,
            @RequestParam("tollFreeNumber") String tollFreeNumber,
            @RequestParam("createdBy") int createdBy,
            @RequestParam("updatedBy") int updatedBy,
            @RequestParam("suspendedStatus") int suspendedStatus) {

        try {
            MunicipalMaster municipalMaster = new MunicipalMaster();
            municipalMaster.setMuniCode(muniCode);
            municipalMaster.setMuniName(muniName);
            municipalMaster.setCity(city);
            municipalMaster.setState(state);
            municipalMaster.setAddressLine1(addressLine1);
            municipalMaster.setAddressLine2(addressLine2);
            municipalMaster.setCommisName(commisName);
            municipalMaster.setContactNumber(contactNumber);
            municipalMaster.setTollFreeNumber(tollFreeNumber);
            municipalMaster.setCreatedBy(createdBy);
            municipalMaster.setUpdatedBy(updatedBy);
            municipalMaster.setSuspendedStatus(suspendedStatus);

            MunicipalMaster createdMunicipal = municipalMasterService.createMunicipalMaster(municipalMaster, logoFile);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdMunicipal);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error creating Municipal Master: " + e.getMessage());
        }
    }

//    @GetMapping("/getAllMunicipalMaster")
//    public ResponseEntity<List<MunicipalMasterDto>> getAllMunicipalMaster() {
//        return ResponseEntity.ok(municipalMasterService.getAllMunicipalMaster());
//    }

//    @GetMapping("/logo/{id}")
//    public ResponseEntity<Resource> getLogo(@PathVariable int id) {
//        try {
//            Resource file = municipalMasterService.loadLogo(id);
//            return ResponseEntity.ok()
//                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
//                    .body(file);
//        } catch (IOException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//        }
//    }

//    @GetMapping("/municipalMaster/{id}")
//    public ResponseEntity<Object> getMunicipalMasterById(@PathVariable int id) {
//        Optional<MunicipalMaster> municipal = municipalMasterService.getMunicipalMasterById(id);
//        if (municipal.isPresent()) {
//            return ResponseEntity.ok(municipal.get());
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("this id is not present");
//        }
//    }


//    @GetMapping("/getByMuniName")
//    public List<MunicipalMaster> getMunicipalMasterByMunicipalName(@RequestParam("muniName") String muniName) {
//        return municipalMasterService.getMunicipalMasterByMuniName(muniName);
//    }


//    @PutMapping("/municipalMaster/update/{id}")
//    public ResponseEntity<MunicipalMaster> updateMunicipalMasterById(@PathVariable int id, @RequestBody MunicipalMaster municipalMaster) {
//        MunicipalMaster updateMunicipalMaster = municipalMasterService.updateMunicipalMasterById(id, municipalMaster);
//        return ResponseEntity.ok(updateMunicipalMaster);
//    }

//    @PatchMapping("/municipalMaster/suspendedStatus/{id}")
//    public ResponseEntity<MunicipalMaster> patchMunicipalMasterSuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
//        MunicipalMaster patchedMunicipalMaster = municipalMasterService.patchMunicipalMasterSuspendedStatus(id, suspendedStatus);
//        return ResponseEntity.ok(patchedMunicipalMaster);
//    }


    @GetMapping("/active")
    public ResponseEntity<List<MunicipalMaster>> getAllActiveMunicipalMaster(@RequestParam(required = false, defaultValue = "0") Integer status){
        List<MunicipalMaster> municipalMasters=municipalMasterService.findAllActiveMunicipalMaster(status);
        return ResponseEntity.ok(municipalMasters);

    }
}
