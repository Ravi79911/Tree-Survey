package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ZoneDto {
        private int id;
        private String zoneName;
        private int createdBy;
        private LocalDateTime createdDate;
        private int updatedBy;
        private LocalDateTime updatedDate;
        private int suspendedStatus;
       // private int municipalMasterId;
        //private Set<ZoneWardDto> zoneWards;

}
