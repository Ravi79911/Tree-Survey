package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.model.ZoneWard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface TreeSurveyMasterRepository extends JpaRepository<TreeSurveyMaster, Integer> {
    Optional<TreeSurveyMaster> findByTreeUUID(String treeUUID);
    //List<TreeSurveyMaster> findByTreeName(String treeName);

    @Query("SELECT t FROM TreeSurveyMaster t JOIN t.treeGroupMaster tg WHERE tg.treeName = :treeName")
    List<TreeSurveyMaster> findByTreeName(@Param("treeName") String treeName);

    @Query("SELECT t FROM TreeSurveyMaster t WHERE t.zoneWard.id = :zoneWardId")
    List<TreeSurveyMaster> findByZoneWardId(int zoneWardId);



    @Query("SELECT t FROM TreeSurveyMaster t " +
            "JOIN t.treeGroupMaster tg " +
            "WHERE t.ownershipOfLand = :ownershipOfLand " +
            "AND t.municipalMaster.id = :municipalId " +
            "AND t.zone.id = :zoneId " +
            "AND t.zoneWard.id = :zoneWardId " +
            "AND tg.treeName = :treeName")
    List<TreeSurveyMaster> findByOwnershipOfLandAndMunicipalIdAndZoneIdAndZoneWardIdAndTreeName(
            @Param("ownershipOfLand") String ownershipOfLand,
            @Param("municipalId") int municipalId,
            @Param("zoneId") int zoneId,
            @Param("zoneWardId") int zoneWardId,
            @Param("treeName") String treeName);


    List<TreeSurveyMaster> findByMunicipalMasterIdAndZoneIdAndZoneWardId(int municipalId, int zoneId, int zoneWardId);

    List<TreeSurveyMaster> findBySuspendedStatus(Integer status);
}
