package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.LoginLogoutSummary;
import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public interface LoginLogoutSummaryService {

    LoginLogoutSummary saveLoginLogoutSummary(LoginLogoutSummary loginLogoutSummary);
//    Optional<LoginLogoutSummary> getUserMasterId(UserMaster userMaster);
}
