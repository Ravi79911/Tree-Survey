package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "tbl_tree_survey_approve_rej_update_status")
@Data
@NoArgsConstructor
public class TreeSurveyStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

//    @Column(name = "tree_survey_mas_id")
//    @NotNull(message = "Tree Survey Master ID cannot be null")
//    private int treeSurveyMasId;

    @Column(name = "is_approved")
    private Boolean isApproved;

    @Column(name = "is_update")
    private Boolean isUpdate;

    @Column(name = "is_rejected")
    private Boolean isRejected;

    @Column(name = "createdby")
    private int createdBy;

    @Column(name = "createddate")
    private LocalDateTime createdDate;

    @Column(name = "suspendedstatus")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "tree_survey_mas_id", referencedColumnName = "id", nullable = false)
    private TreeSurveyMaster treeSurveyMaster;
}