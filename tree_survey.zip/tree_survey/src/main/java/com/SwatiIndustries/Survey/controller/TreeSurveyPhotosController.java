package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.TreeSurveyPhotos;
import com.SwatiIndustries.Survey.repository.TreeSurveyMasterRepository;
import com.SwatiIndustries.Survey.service.TreeSurveyPhotosService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("treeSurveyPhotos")
public class TreeSurveyPhotosController {

    @Autowired
    TreeSurveyMasterRepository treeSurveyMasterRepository;

    @Autowired
    TreeSurveyPhotosService treeSurveyPhotosService;

    @PostMapping("/createTreeSurveyPhotos")
    public ResponseEntity<TreeSurveyPhotos> createTreeSurveyPhotos(
            @Valid
            @RequestParam(value = "photoTree1", required = false) MultipartFile photoTree1,
            @RequestParam(value = "photoTree2", required = false) MultipartFile photoTree2,
            @RequestParam(value = "photoTree3", required = false) MultipartFile photoTree3,
            @RequestParam(value = "photoLeaf", required = false) MultipartFile photoLeaf,
            @RequestParam(value = "photoTrunk", required = false) MultipartFile photoTrunk,
            @RequestParam(value = "photoFlower", required = false) MultipartFile photoFlower,
            @RequestParam(value = "photoFruits", required = false) MultipartFile photoFruits,
            @RequestParam(value = "photoOthers", required = false) MultipartFile photoOthers,
            @RequestParam(value = "treeSurveyMasId") int treeSurveyMasId,
            @RequestParam(value = "isIdentified") boolean isIdentified,
            @RequestParam(value = "createdBy") int createdBy,
            //@RequestParam(value = "createdDate") int createdDate,
            @RequestParam(value = "suspendedStatus") int suspendedStatus) {

        TreeSurveyPhotos treeSurveyPhotos = new TreeSurveyPhotos();
        treeSurveyPhotos.setTreeSurveyMaster(treeSurveyMasterRepository.findById(treeSurveyMasId).get());
        treeSurveyPhotos.setIsIdentified(isIdentified);
        treeSurveyPhotos.setCreatedBy(createdBy);
        treeSurveyPhotos.setSuspendedStatus(suspendedStatus);
        TreeSurveyPhotos createTreePhotos = treeSurveyPhotosService.createTreeSurveyPhotos(treeSurveyPhotos, photoTree1, photoTree2,
                photoTree3, photoLeaf, photoTrunk, photoFlower, photoFruits, photoOthers);

        return ResponseEntity.status(HttpStatus.CREATED).body(createTreePhotos);
    }

    @GetMapping("/getAllTreeSurveyPhotos")
    public ResponseEntity<List<TreeSurveyPhotos>> getAllTreeSurveyPhotos() {
        List<TreeSurveyPhotos> treeSurveyPhotos = treeSurveyPhotosService.getAllTreeSurveyPhotos();
        return ResponseEntity.status(HttpStatus.OK).body(treeSurveyPhotos);
    }

    @GetMapping("/photos/{id}")
    public ResponseEntity<Resource> getLogo(@PathVariable int id) {
        try {
            Resource file = treeSurveyPhotosService.loadPhotos(id);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
                    .body(file);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }


    }




