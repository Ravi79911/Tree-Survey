package com.SwatiIndustries.Survey.serviceImpl;


import com.SwatiIndustries.Survey.dto.UserPasswordChangeDTO;
import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.model.UserPasswordChange;
import com.SwatiIndustries.Survey.repository.UserPasswordChangeRepository;
import com.SwatiIndustries.Survey.service.UserPasswordChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserPasswordChangeServiceImpl implements UserPasswordChangeService {

    @Autowired
    private UserPasswordChangeRepository userPasswordChangeRepository;

    private final BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

    @Override
    public UserPasswordChange createUserPasswordChange(UserPasswordChange request) {
        request.setCurrentPwd(bCryptPasswordEncoder.encode(request.getCurrentPwd()));
        request.setLastPwd(bCryptPasswordEncoder.encode(request.getLastPwd()));
        request.setChangeDateTime(LocalDateTime.now());
        request.setCreatedDate(LocalDateTime.now());
        request.setUpdatedDate(LocalDateTime.now());

        return userPasswordChangeRepository.save(request);
    }

    @Override
    public UserPasswordChange updateUserPasswordChange(Integer id, UserPasswordChange request) {
        // Fetch the existing entity
        UserPasswordChange existingEntity = userPasswordChangeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("UserPasswordChange not found with id: " + id));

        // Update the fields
        existingEntity.setCurrentPwd(bCryptPasswordEncoder.encode(request.getCurrentPwd()));
        existingEntity.setLastPwd(bCryptPasswordEncoder.encode(request.getLastPwd()));
        existingEntity.setChangeDateTime(LocalDateTime.now());
        existingEntity.setUpdatedDate(LocalDateTime.now());

        // Save and return the updated entity
        return userPasswordChangeRepository.save(existingEntity);
    }

    @Override
    public Optional<UserPasswordChange> getUserMasterId(UserMaster userMaster) {
        return userPasswordChangeRepository.findByUserMaster(userMaster); // Update method call
    }


}
