package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.UserMasterDemo;
import com.SwatiIndustries.Survey.serviceImpl.UserMasterDemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

//@CrossOrigin
//@RestController
//@RequestMapping("/api/login")
//@Validated
//public class UserMasterControllerDemo {
//
//    @Autowired
//    private UserMasterDemoService userMasterService;
//
//    @PostMapping
//    public ResponseEntity<?> login(@RequestParam String username, @RequestParam String password) {
//        Optional<UserMasterDemo> user = userMasterService.login(username, password);
//        if (user.isPresent()) {
//            return ResponseEntity.ok(user.get()); // Return user info
//        } else {
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Login failed: Invalid username or password");
//        }
//    }
//}
