package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.UserRoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface UserRoleMasterRepository extends JpaRepository<UserRoleMaster, Integer> {

    List<UserRoleMaster> findBySuspendedStatus(Integer status) ;
}
