package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreeSurveyAnotherDetailsDto {

    private int id;
    private String economicalImportance;
    private String IUCN_category;
    private boolean pollutionTolerantSpecies;
    private boolean carbonAbsorbent;
    private boolean carbonSequestration;
    private boolean tempratureRegulatingSpecies;
    private int createdBy;
    private LocalDate createdDate;
    private int suspendedStatus;
    private int treeSurveyMasId;
}