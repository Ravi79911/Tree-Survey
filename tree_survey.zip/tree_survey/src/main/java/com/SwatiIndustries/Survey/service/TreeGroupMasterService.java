package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.TreeGroupMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TreeGroupMasterService {

    List<TreeGroupMaster> getAllTreeGroupMaster();

}
