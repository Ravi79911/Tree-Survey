package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.LoginLogoutSummary;
import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.model.UserPasswordChange;
import com.SwatiIndustries.Survey.service.LoginLogoutSummaryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/LoginLogoutSummary")
public class LoginLogoutSummaryController {

    @Autowired
    private LoginLogoutSummaryService loginLogoutSummaryService;

    @PostMapping("/create")
    public ResponseEntity<LoginLogoutSummary> create(@Valid@RequestBody LoginLogoutSummary loginLogoutSummary) {
        LoginLogoutSummary savedLoginLogoutSummary = loginLogoutSummaryService.saveLoginLogoutSummary(loginLogoutSummary);
        return new ResponseEntity<>(savedLoginLogoutSummary, HttpStatus.CREATED);
    }

//    @GetMapping("/findByUserId")
//    public ResponseEntity<LoginLogoutSummary> getUserInfoById(@RequestParam Integer userMasterId) {
//        UserMaster userMaster = new UserMaster();
//        userMaster.setId(userMasterId); // Set ID to userMaster
//        Optional<LoginLogoutSummary> userInfo = loginLogoutSummaryService.getUserMasterId(userMaster); // Pass UserMaster object
//        return userInfo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
//    }

}
