package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "tbl_approval_mapping_details")
public class ApprovalMappingDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "can_forward")
    private Boolean canForward;

    @Column(name = "can_backward")
    private Boolean canBackward;

    @ManyToOne
    @JoinColumn(name = "can_forward_to_role_id", referencedColumnName = "id")
    private UserRoleMaster canForwardToRole;

    @ManyToOne
    @JoinColumn(name = "role_id", referencedColumnName = "id")
    private UserRoleMaster role;

    @ManyToOne
    @JoinColumn(name = "can_backward_to_role_id", referencedColumnName = "id")
    private UserRoleMaster canBackToRole;

    @NotNull(message = "Municipal ID is required")
    @ManyToOne
    @JoinColumn(name = "municipal_mas_id", nullable = false)
    private MunicipalMaster municipalMaster;

    @Column(name = "can_reject")
    private Boolean canReject;

    @Column(name = "can_approved")
    private Boolean canApproved;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private Integer suspendedStatus;
}

