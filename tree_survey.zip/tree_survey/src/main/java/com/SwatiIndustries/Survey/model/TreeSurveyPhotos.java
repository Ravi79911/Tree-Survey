package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_tree_survey_upload_photo")
public class TreeSurveyPhotos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

//    @NotNull
//    @Column(name = "tree_survey_mas_id")
//    private int treeSurveyMasId;

    @NotNull
    @Column(name = "photo_tree1", columnDefinition = "varchar(MAX)")
    private String photoTree1;

    @NotNull
    @Column(name = "photo_tree2", columnDefinition = "varchar(MAX)")
    private String photoTree2;

    @Column(name = "photo_tree3", columnDefinition = "varchar(MAX)")
    private String photoTree3;

    @NotNull
    @Column(name = "is_identified")
    private Boolean isIdentified;

    @Column(name = "photo_leaf", columnDefinition = "varchar(MAX)")
    private String photoLeaf;

    @Column(name = "photo_trunk", columnDefinition = "varchar(MAX)")
    private String photoTrunk;

    @Column(name = "photo_flower", columnDefinition = "varchar(MAX)")
    private String photoFlower;

    @Column(name = "photo_fruits", columnDefinition = "varchar(MAX)")
    private String photoFruits;

    @Column(name = "photo_others", columnDefinition = "varchar(MAX)")
    private String photoOthers;

    @NotNull
    @Column(name = "createdby")
    private int createdBy;

    @NotNull
    @Column(name = "createddate")
    private LocalDateTime createdDate;

    @NotNull
    @Column(name = "suspendedstatus")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "tree_survey_mas_id", referencedColumnName = "id", nullable = false)
    private TreeSurveyMaster treeSurveyMaster;

}
