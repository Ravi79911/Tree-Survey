package com.SwatiIndustries.Survey.serviceImpl;


import com.SwatiIndustries.Survey.dto.ZoneDto;
import com.SwatiIndustries.Survey.dto.ZoneWardDto;
import com.SwatiIndustries.Survey.exception.ResourceNotFoundException;
import com.SwatiIndustries.Survey.model.Zone;
import com.SwatiIndustries.Survey.model.ZoneWard;
import com.SwatiIndustries.Survey.repository.ZoneWardRepository;
import com.SwatiIndustries.Survey.service.ZoneWardService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ZoneWardServiceImpl implements ZoneWardService {

    @Autowired
    ZoneWardRepository zoneWardRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ZoneWard createZoneWard(ZoneWard zoneWard) {
        zoneWard.setCreatedDate(LocalDateTime.now());
        zoneWard.setSuspendedStatus(0);
        zoneWard.setUpdatedDate(LocalDateTime.now());
        return zoneWardRepository.saveAndFlush(zoneWard);
    }

    @Override
    public List<ZoneWardDto> getAllZoneWard() {
        List<ZoneWard> zoneWards = zoneWardRepository.findAll();
        return zoneWards.stream()
                .map(zoneWard -> modelMapper.map(zoneWard, ZoneWardDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ZoneWard> getByWardNo(String wardNo) {
        return zoneWardRepository.findByWardNo(wardNo);
    }

    @Override
    public List<ZoneWard> getZoneWardByMunicipalId(int municipalId) {
        List<ZoneWard> zoneWards = zoneWardRepository.findByMunicipalMasterId(municipalId);
        if (zoneWards.isEmpty()) {
            throw new ResourceNotFoundException("Municipal ID", "municipalId", municipalId);
        }
        return zoneWards.stream().map(zoneWard -> modelMapper.map(zoneWard, ZoneWard.class))
                .collect(Collectors.toList());
    }

    // Method to get all ZoneWards by Zone ID
    public List<ZoneWardDto> getZoneWardsByZoneId(int zoneId) {
        List<ZoneWard> zoneWards = zoneWardRepository.findByZoneId(zoneId);
        return zoneWards.stream()
                .map(zoneWard -> modelMapper.map(zoneWard, ZoneWardDto.class)) // Corrected mapping to ZoneWardDto
                .collect(Collectors.toList());
    }



    @Override
    public Optional<ZoneWard> getZoneWardById(int id) {
        return zoneWardRepository.findById(id);
    }

//    @Override
//    public ZoneWard updateZoneWard(int id, ZoneWard zoneWard) {
//        zoneWard.setId(id);
//        return zoneWardRepository.saveAndFlush(zoneWard);
//    }

//    @Override
//    public ZoneWard patchSuspendedStatus(int id, int suspendedStatus) {
//        Optional<ZoneWard> optionalZoneWard = zoneWardRepository.findById(id);
//        if (optionalZoneWard.isPresent()) {
//            ZoneWard existingZoneWard = optionalZoneWard.get();
//            existingZoneWard.setSuspendedStatus(suspendedStatus);
//            return zoneWardRepository.saveAndFlush(existingZoneWard);
//        } else {
//            throw new RuntimeException("ZoneWard not found with id: " + id);
//        }

    }


