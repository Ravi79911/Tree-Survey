package com.SwatiIndustries.Survey.serviceImpl;


import com.SwatiIndustries.Survey.model.UserMasterDemo;
import com.SwatiIndustries.Survey.repository.UserMasterDemoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserMasterDemoService {

    @Autowired
    private UserMasterDemoRepository userMasterRepository;

    public Optional<UserMasterDemo> login(String username, String password) {
        Optional<UserMasterDemo> user = userMasterRepository.findByUsername(username);
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user;
        }
        return Optional.empty();
    }
}
