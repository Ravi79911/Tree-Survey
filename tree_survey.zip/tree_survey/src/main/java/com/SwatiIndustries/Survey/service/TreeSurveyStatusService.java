package com.SwatiIndustries.Survey.service;


import com.SwatiIndustries.Survey.model.TreeSurveyStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TreeSurveyStatusService {

    TreeSurveyStatus saveTreeSurveyStatus(TreeSurveyStatus treeSurveyStatus);

    List<TreeSurveyStatus> findAll();
    Optional<TreeSurveyStatus> findById(Integer id);

}
