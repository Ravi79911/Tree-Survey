package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.UserRoleMaster;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserRoleMasterService {

    UserRoleMaster saveUserRoleMaster(UserRoleMaster userRoleMaster);

    List<UserRoleMaster> findAllActiveUserRoleMaster(Integer status);
}
