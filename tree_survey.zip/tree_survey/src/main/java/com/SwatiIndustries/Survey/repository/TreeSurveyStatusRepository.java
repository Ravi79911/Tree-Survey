package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.TreeSurveyStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@EnableJpaRepositories
public interface TreeSurveyStatusRepository extends JpaRepository<TreeSurveyStatus,Integer> {
}
