package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Tbl_trees_servey_master")
public class TreeSurveyMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "survey_date")
    private LocalDate surveyDate;

    @Column(name = "survey_time")
    private LocalDateTime surveyTime;

    @Column(name = "tree_UUID")
    private String treeUUID;

    @Transient
    @Size(max = 100)
    private String localName;

    @Transient
    @Size(max = 150)
    private String scientificName;

    @NotNull
    @Size(max = 50)
    @Column(name = "girth")
    private String girth;

    @NotNull
    @Size(max = 10)
    @Column(name = "height")
    private String height;

    @NotNull
    @Column(name = "age_year")
    private int ageYear;

    @NotNull
    @Column(name = "age_month")
    private int ageMonth;

    @NotNull
    @Column(name = "age_days")
    private int ageDays;

    @NotNull
    @Size(max = 150)
    @Column(name = "health_condition")
    private String healthCondition;

    @NotNull
    @Size(max = 50)
    @Column(name = "tree_canopy")
    private String treeCanopy;

    @NotNull
    @Size(max = 100)
    @Column(name = "ownership_of_land")
    private String ownershipOfLand;

    @NotNull
    @Column(name = "is_tree_heritage")
    private Boolean isTreeHeritage;

    @NotNull
    @Size(max = 50)
    @Column(name = "latitude")
    private String latitude;

    @NotNull
    @Size(max = 50)
    @Column(name = "longitude")
    private String longitude;

    @NotNull
    @Column(name = "createdby")
    private int createdBy;

    @Column(name = "createddate")
    private LocalDateTime createdDate;

    @NotNull
    @Column(name = "suspendedstatus")
    private int suspendedStatus;

    @ManyToOne
    @JoinColumn(name = "tree_group_master_id", referencedColumnName = "id", nullable = false)
    private TreeGroupMaster treeGroupMaster;

    @NotNull(message = "Municipal ID is required")
    @ManyToOne
    @JoinColumn(name = "municipal_id", nullable = false)
    private MunicipalMaster municipalMaster;

    @ManyToOne
    @JoinColumn(name = "zone_mas_id")
    private Zone zone;

    @ManyToOne
    @JoinColumn(name = "zone_ward_mas_id")
    private ZoneWard zoneWard;

    @Transient
    public String getLocalName() {
        return (treeGroupMaster != null) ? treeGroupMaster.getTreeName() : null;
    }

    @Transient
    public String getScientificName() {
        return (treeGroupMaster != null) ? treeGroupMaster.getScientificName() : null;
    }

    @OneToMany(mappedBy = "treeSurveyMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<TreeCuttingPruningDetails> treeCuttingPruningDetails;
}

