package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Tbl_User_Master")
public class UserMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @NotBlank(message = "Name cannot be blank")
    @Column(name = "name_off", nullable = false)
    private String nameOff;

    @NotBlank(message = "Designation cannot be blank")
    @Column(name = "designation", nullable = false)
    private String designation;

    @NotBlank(message = "Department cannot be blank")
    @Column(name = "department", nullable = false)
    private String department;

    @NotNull(message = "Municipal ID is required")
    @ManyToOne
    @JoinColumn(name = "municipal_mas_id", nullable = false)
    private MunicipalMaster municipalMasterid;

    @NotNull(message = "UserRoleType ID is required")
    @ManyToOne
    @JoinColumn(name = "role_type_id", nullable = false)
    private UserRoleMaster userRoleMasterid;

    @Pattern(regexp = "^\\+?[0-9. ()-]{7,25}$", message = "Invalid mobile number")
    @Column(name = "mobile_no", nullable = false)
    private String mobileNo;

    @Email(message = "Invalid email address")
    @Column(name = "email_id", nullable = false)
    private String emailId;

    @Column(name = "user_photo")
    private String userPhoto;

    @NotBlank(message = "Username cannot be blank")
    @Column(name = "user_name", nullable = false)
    private String userName;

    @NotBlank(message = "Password cannot be blank")
    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @Column(name = "upated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status", nullable = false)
    private Integer suspendedStatus;

    @OneToMany(mappedBy = "userMaster", cascade = CascadeType.ALL)
    private Set<UserInfo> userInfo;

    @OneToMany(mappedBy = "userMaster", cascade = CascadeType.ALL)
    private Set<UserPasswordChange> userPasswordChanges;

    @OneToMany(mappedBy = "userMaster", cascade = CascadeType.ALL)
    private Set<LoginLogoutSummary> loginLogoutSummaries;
}
