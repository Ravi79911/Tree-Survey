package com.SwatiIndustries.Survey.controller;


import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.model.UserPasswordChange;
import com.SwatiIndustries.Survey.service.UserPasswordChangeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@RequestMapping("/userPasswordChange")
@CrossOrigin
public class UserPasswordChangeController {

    @Autowired
    private UserPasswordChangeService userPasswordChangeService;

    @PostMapping("/create")
    public ResponseEntity<UserPasswordChange> createUserPasswordChange(@Valid @RequestBody UserPasswordChange request) {
        UserPasswordChange savedUserPasswordChange = userPasswordChangeService.createUserPasswordChange(request);
        return new ResponseEntity<>(savedUserPasswordChange, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<UserPasswordChange> updateUserPasswordChange(
            @PathVariable Integer id,
            @Valid @RequestBody UserPasswordChange request) {
        UserPasswordChange updatedUserPasswordChange = userPasswordChangeService.updateUserPasswordChange(id, request);
        return new ResponseEntity<>(updatedUserPasswordChange, HttpStatus.OK);
    }

    @GetMapping("/findByUserId")
    public ResponseEntity<UserPasswordChange> getUserInfoById(@RequestParam Integer userMasterId) {
        UserMaster userMaster = new UserMaster();
        userMaster.setId(userMasterId); // Set ID to userMaster
        Optional<UserPasswordChange> userInfo = userPasswordChangeService.getUserMasterId(userMaster); // Pass UserMaster object
        return userInfo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

}
