package com.SwatiIndustries.Survey.service;


import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.PropertyOwnerDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


public interface PropertyOwnerDetailsService {
    PropertyOwnerDetails savePropertyOwnerDetails(PropertyOwnerDetails propertyOwnerDetails);
    List<PropertyOwnerDetails> getAllPropertyOwnerDetails();
    List<PropertyOwnerDetails> getPropertyOwnerDetailsByTreeSurveyMasterId(int treeSurveyMasterId);
    List<PropertyOwnerDetails> findByTreeSurveyMaster(TreeSurveyMaster treeSurveyMaster);
    Optional<PropertyOwnerDetails> findById(Integer id);
    PropertyOwnerDetails patchPropertyOwnerDetailsSuspendedStatus(int id, int suspendedStatus);
}
