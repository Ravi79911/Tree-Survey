package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.TreeCuttingPruningDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.serviceImpl.TreeCuttingPruningDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tree-cutting-pruning")
@CrossOrigin
public class TreeCuttingPruningDetailsController {

    @Autowired
    private TreeCuttingPruningDetailsServiceImpl service;

    @PostMapping("/save")
    public ResponseEntity<List<TreeCuttingPruningDetails>> saveDetails(
            @RequestParam List<Integer> treeSurveyMasterIds,
            @RequestParam int cuttingAndPruningMasterId) {

        try {
            List<TreeCuttingPruningDetails> savedDetails = service.save(treeSurveyMasterIds, cuttingAndPruningMasterId);
            return new ResponseEntity<>(savedDetails, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/details/{id}")
    public ResponseEntity<TreeCuttingPruningDetails> getDetailsById(@PathVariable int id) {
        Optional<TreeCuttingPruningDetails> details = service.findById(id);

        if (details.isPresent()) {
            return new ResponseEntity<>(details.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/by-cutting-pruning-master/{cuttingAndPruningMasterId}")
    public ResponseEntity<List<TreeCuttingPruningDetails>> getDetailsByCuttingAndPruningMasterId(@PathVariable int cuttingAndPruningMasterId) {
        try {
            List<TreeCuttingPruningDetails> detailsList = service.findByCuttingAndPruningMasterId(cuttingAndPruningMasterId);
            if (detailsList.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(detailsList, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
