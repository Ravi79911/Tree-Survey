package com.SwatiIndustries.Survey.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class TreeUuidAutomaticGenerate {

    private static final String PREFIX = "TRE";
    private static final AtomicInteger counter = new AtomicInteger();

    public static String generateApplicationNo() {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("ddMMyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmmssSSS");
        LocalDateTime now = LocalDateTime.now();

        String datePart = now.format(dateFormatter);
        String timePart = now.format(timeFormatter);
        int uniqueNumber = counter.incrementAndGet();
        String uniqueNumberPart = String.format("%05d", uniqueNumber);

        return PREFIX + datePart + timePart + uniqueNumberPart;
    }
}
