package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.repository.UserInfoRepository;
import com.SwatiIndustries.Survey.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserInfoServiceImpl implements UserInfoService {

    @Autowired
    private UserInfoRepository userDetailsRepository;

    @Override
    public UserInfo saveUserInfo(UserInfo userInfo) {
        userInfo.setCreatedDate(LocalDateTime.now());
        userInfo.setUpdatedDate(LocalDateTime.now());
        userInfo.setSuspendedStatus(0);
        return userDetailsRepository.save(userInfo);
    }

    @Override
    public List<UserInfo> getAllActiveUsersBySuspendedStatus(Integer suspendedStatus) {
        return userDetailsRepository.findBySuspendedStatus(suspendedStatus);
    }

    @Override
    public Optional<UserInfo> getUserMasterId(UserMaster userMaster) {
        return userDetailsRepository.findByUserMaster(userMaster); // Update method call
    }
}
