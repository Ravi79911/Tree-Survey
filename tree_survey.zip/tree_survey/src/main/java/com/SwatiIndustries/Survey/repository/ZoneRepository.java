package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.Zone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface ZoneRepository extends JpaRepository<Zone, Integer> {

    //List<Zone> findByMunicipalMasterId(int municipalId);

    List<Zone> findBySuspendedStatus(int status);

    Optional<Zone> findZoneById(int id);

    @Query("SELECT z FROM Zone z WHERE z.municipalMaster.id = :municipalId")
    List<Zone> findByMunicipalId(int municipalId);

   // List<Zone> findAllByMunicipalId(int municipalId);
}
