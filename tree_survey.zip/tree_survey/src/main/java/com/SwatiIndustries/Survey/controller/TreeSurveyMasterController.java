package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.dto.TreeSurveyMasterDto;
import com.SwatiIndustries.Survey.dto.TreeSurveyResponseDTO;
import com.SwatiIndustries.Survey.model.MunicipalMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.model.TreeSurveyStatus;
import com.SwatiIndustries.Survey.model.ZoneWard;
import com.SwatiIndustries.Survey.service.TreeSurveyMasterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/treeSurveyMaster")
public class TreeSurveyMasterController {

    @Autowired
    TreeSurveyMasterService treeSurveyMasterService;

    @PostMapping("/createTreeSurveyMaster")
    public ResponseEntity<TreeSurveyMaster> createTreeSurveyMasters(@Valid @RequestBody TreeSurveyMaster treeSurveyMaster) {
        TreeSurveyMaster createTreeSurvey = treeSurveyMasterService.createTreeSurveyMaster(treeSurveyMaster);
        return ResponseEntity.status(HttpStatus.CREATED).body(createTreeSurvey);
    }

//    @GetMapping("/getAllTreeSurveyMasters")
//    public ResponseEntity<List<TreeSurveyMaster>> getAllTreeSurveyMasters() {
//        List<TreeSurveyMaster> treeSurveyMasters = treeSurveyMasterService.getAllTreeSurveyMasters();
//        return ResponseEntity.ok(treeSurveyMasters);
//    }

    @GetMapping("/{treeUUID}")
    public ResponseEntity<TreeSurveyResponseDTO> getTreeSurveyDetailsByTreeUUID(@PathVariable String treeUUID) {
        TreeSurveyResponseDTO response = treeSurveyMasterService.getTreeSurveyDetailsByTreeUUID(treeUUID);
        return ResponseEntity.ok(response);
    }

//    @PutMapping("/{id}")
//    public ResponseEntity<TreeSurveyMaster> updateStatus(@PathVariable Integer id, @Valid @RequestBody TreeSurveyMaster surveyMaster) {
//        if (treeSurveyMasterService.findById(id).isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//        surveyMaster.setId(id);
//        TreeSurveyMaster updatedStatus = treeSurveyMasterService.createTreeSurveyMaster(surveyMaster);
//        return ResponseEntity.ok(updatedStatus);
//    }

    @PatchMapping("/TreeSurveyMaster/suspendedStatus/{id}")
    public ResponseEntity<TreeSurveyMaster> patchTreeSurveySuspendedStatus(@PathVariable int id, @RequestParam int suspendedStatus) {
        TreeSurveyMaster patchedTreeSurveyMaster = treeSurveyMasterService.patchTreeSurveyMasterSuspendedStatus(id, suspendedStatus);
        return ResponseEntity.ok(patchedTreeSurveyMaster);
    }

//    @GetMapping("/getByTreeName")
//    public List<TreeSurveyMaster> findByTreeName(@RequestParam("treeName") String treeName) {
//        return treeSurveyMasterService.findByTreeName(treeName);
//    }

//    @GetMapping("/zone-ward/{zoneWardId}/trees")
//    public ResponseEntity<List<String>> getTreeNamesByZoneWardId(@PathVariable int zoneWardId) {
//        List<String> treeNames = treeSurveyMasterService.getTreeNamesByZoneWardId(zoneWardId);
//        return ResponseEntity.ok(treeNames);
//    }

    @PostMapping("/ByWhereCondition")
    public ResponseEntity<List<Map<String, Object>>> getTreeDetails(@RequestParam int municipalId,
                                                                    @RequestParam int zoneId,
                                                                    @RequestParam int zoneWardId) {
        List<TreeSurveyMasterDto> results = treeSurveyMasterService.getTreeSurveysByWhereCondition(municipalId, zoneId, zoneWardId);
        if (results.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        List<Map<String, Object>> response = results.stream()
                .map(result -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("treeId", result.getId());
                    map.put("treeName", result.getTreeGroupMaster().getTreeName());
                    // Add other fields from TreeSurveyMasterDto if needed
                    map.put("treeUUID", result.getTreeUUID());

                    return map;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }

    @PostMapping("/by-ownership-and-filters")
    public ResponseEntity<List<TreeSurveyMasterDto>> getTreeSurveysByOwnershipAndFilters(
            @RequestParam String ownershipOfLand,
            @RequestParam int municipalId,
            @RequestParam int zoneId,
            @RequestParam int zoneWardId,
            @RequestParam String treeName) {

        List<TreeSurveyMaster> treeSurveyMasters = treeSurveyMasterService.getTreeSurveyMastersByOwnershipOfLandAndFilters(
                ownershipOfLand, municipalId, zoneId, zoneWardId, treeName);

        // Convert TreeSurveyMaster to TreeSurveyMasterDto
        List<TreeSurveyMasterDto> dtos = treeSurveyMasters.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    private TreeSurveyMasterDto convertToDto(TreeSurveyMaster treeSurveyMaster) {
        TreeSurveyMasterDto dto = new TreeSurveyMasterDto();
        dto.setId(treeSurveyMaster.getId());
        dto.setSurveyDate(treeSurveyMaster.getSurveyDate());
        dto.setSurveyTime(treeSurveyMaster.getSurveyTime());
        dto.setTreeUUID(treeSurveyMaster.getTreeUUID());
        dto.setGirth(treeSurveyMaster.getGirth());
        dto.setHeight(treeSurveyMaster.getHeight());
        dto.setAgeYear(treeSurveyMaster.getAgeYear());
        dto.setAgeMonth(treeSurveyMaster.getAgeMonth());
        dto.setAgeDays(treeSurveyMaster.getAgeDays());
        dto.setHealthCondition(treeSurveyMaster.getHealthCondition());
        dto.setTreeCanopy(treeSurveyMaster.getTreeCanopy());
        dto.setOwnershipOfLand(treeSurveyMaster.getOwnershipOfLand());

        dto.setIsTreeHeritage(treeSurveyMaster.getIsTreeHeritage());
        dto.setLatitude(treeSurveyMaster.getLatitude());
        dto.setLongitude(treeSurveyMaster.getLongitude());
        dto.setCreatedBy(treeSurveyMaster.getCreatedBy());
        dto.setCreatedDate(treeSurveyMaster.getCreatedDate());
        dto.setSuspendedStatus(treeSurveyMaster.getSuspendedStatus());

        // Set localName and scientificName using TreeGroupMaster
        if (treeSurveyMaster.getTreeGroupMaster() != null) {
            dto.setLocalName(treeSurveyMaster.getTreeGroupMaster().getTreeName());
            dto.setScientificName(treeSurveyMaster.getTreeGroupMaster().getScientificName());
        }

        // If you need to convert the TreeGroupMaster entity as well
        // dto.setTreeGroupMaster(convertToTreeGroupMasterDto(treeSurveyMaster.getTreeGroupMaster()));

        return dto;
    }

    @PutMapping("/UpdateTreeSurveyMaster{id}")
    public ResponseEntity<TreeSurveyMaster> updateTreeSurvey(@PathVariable int id, @RequestBody TreeSurveyMaster treeSurveyMasterDetails) {
        TreeSurveyMaster updatedTreeSurvey = treeSurveyMasterService.updateTreeSurvey(id, treeSurveyMasterDetails);
        return ResponseEntity.ok(updatedTreeSurvey);
    }

    @GetMapping("/active")
    public ResponseEntity<List<TreeSurveyMaster>> getAllActiveTreeSurveyMaster(@RequestParam(required = false, defaultValue = "0") Integer status){
        List<TreeSurveyMaster> treeSurveyMasters=treeSurveyMasterService.findAllActiveTreeSurveyMaster(status);
        return ResponseEntity.ok(treeSurveyMasters);

    }
}



