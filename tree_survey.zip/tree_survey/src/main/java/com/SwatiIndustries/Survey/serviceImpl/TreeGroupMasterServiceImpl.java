package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.TreeGroupMaster;
import com.SwatiIndustries.Survey.repository.TreeGroupMasterRepository;
import com.SwatiIndustries.Survey.service.TreeGroupMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TreeGroupMasterServiceImpl implements TreeGroupMasterService {

    @Autowired
    TreeGroupMasterRepository treeGroupMasterRepository;

    @Override
    public List<TreeGroupMaster> getAllTreeGroupMaster() {
        return treeGroupMasterRepository.findAll();
    }
}
