package com.SwatiIndustries.Survey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CuttingAndPruningMasterDTO {
    private int id;
    private String applyFrom;
    private MunicipalMasterDto municipalMaster;
    private ZoneDto zone;
    private ZoneWardDto zoneWard;
    private String applyFor;
    private String applicantName;
    private String mobileNo;
    private String emailId;
    private String address;
    private String designation;
    private String department;
    private String purpose;
    private String requestRemarks;
    private int createdBy;
    private LocalDateTime createdDate;
    private int updatedBy;
    private LocalDateTime updatedDate;
    private int suspendedStatus;
}