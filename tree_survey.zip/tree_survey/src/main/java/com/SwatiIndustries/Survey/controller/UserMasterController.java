package com.SwatiIndustries.Survey.controller;

import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.service.UserMasterService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/userMaster")
public class UserMasterController {

    @Autowired
    private UserMasterService userMasterService;


    @PostMapping("/create")
    public ResponseEntity<UserMaster> createUser(
            @ModelAttribute UserMaster userMaster,
            @RequestParam("photo") MultipartFile photoFile) {

        try {
            UserMaster savedUser = userMasterService.saveUserMaster(userMaster, photoFile);
            return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/All-ActiveUsers")
    public ResponseEntity<List<UserMaster>> getUsersBySuspendedStatus(@RequestParam (required = false, defaultValue = "0")Integer suspendedStatus) {
        List<UserMaster> users = userMasterService.getUsersBySuspendedStatus(suspendedStatus);
        return ResponseEntity.ok(users);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<UserMaster> updateUserMasterById(
            @PathVariable Integer id,
            @ModelAttribute UserMaster userMaster,
            @RequestParam(value = "photo", required = false) MultipartFile photoFile) {

        try {
            UserMaster updatedUser = userMasterService.updateUserMasterById(id, userMaster, photoFile);
            return new ResponseEntity<>(updatedUser, HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
