package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.model.UserMaster;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public interface UserMasterService {

    UserMaster saveUserMaster(UserMaster userMaster, MultipartFile photoFile) throws IOException;

    List<UserMaster> getUsersBySuspendedStatus(Integer suspendedStatus);
    UserMaster updateUserMasterById(Integer id, UserMaster updatedUserMaster, MultipartFile photoFile) throws IOException;
}
