package com.SwatiIndustries.Survey.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_zone_ward_master")
public class ZoneWard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotNull(message = "Ward number is required")
    @Size(min = 1, message = "Ward number cannot be blank")
    @Column(name = "ward_no")
    private String wardNo;

    @NotNull(message = "Created by is required")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @Column(name = "suspended_status")
    private int suspendedStatus;

//    @NotNull(message = "municipal id is required")
//    @Column(name = "municipal_id")
//    private int municipalId;

    @ManyToOne
    @JoinColumn(name = "zone_mas_id")
    private Zone zone;

    @NotNull(message = "Municipal ID is required")
    @ManyToOne
    @JoinColumn(name = "municipal_id", nullable = false)
    private MunicipalMaster municipalMaster;

    @OneToMany(mappedBy = "zoneWard", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<CuttingAndPruningMaster> cuttingAndPruningMasters;

    @OneToMany(mappedBy = "zoneWard", cascade = CascadeType.ALL)
    private Set<UserInfo> userInfo;
}
