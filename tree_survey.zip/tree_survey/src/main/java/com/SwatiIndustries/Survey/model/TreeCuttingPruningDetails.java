package com.SwatiIndustries.Survey.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_tree_cutting_purning_details")
public class TreeCuttingPruningDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @ManyToOne
    @JoinColumn(name = "cutting_purning_mas_id", nullable = false)
    private CuttingAndPruningMaster cuttingAndPruningMaster;

    @ManyToOne
    @JoinColumn(name = "Tree_survey_id", referencedColumnName = "id", nullable = false)
    private TreeSurveyMaster treeSurveyMaster;

    @Column(name = "Tree_name")
    private String treeName;

    @Column(name = "UUID_no", unique = true, nullable = false)
    private String uuidNo;

    @Column(name = "cutt_purn_request_remarks")
    private String cuttPurnRequestRemarks;
}