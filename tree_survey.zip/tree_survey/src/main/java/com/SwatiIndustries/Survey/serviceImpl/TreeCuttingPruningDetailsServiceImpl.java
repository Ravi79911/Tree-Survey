package com.SwatiIndustries.Survey.serviceImpl;

import com.SwatiIndustries.Survey.model.CuttingAndPruningMaster;
import com.SwatiIndustries.Survey.model.TreeCuttingPruningDetails;
import com.SwatiIndustries.Survey.model.TreeSurveyMaster;
import com.SwatiIndustries.Survey.repository.CuttingAndPruningMasterRepository;
import com.SwatiIndustries.Survey.repository.TreeCuttingPruningDetailsRepository;
import com.SwatiIndustries.Survey.repository.TreeSurveyMasterRepository;
import com.SwatiIndustries.Survey.service.TreeCuttingPruningDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TreeCuttingPruningDetailsServiceImpl implements TreeCuttingPruningDetailsService {

    @Autowired
    private TreeCuttingPruningDetailsRepository repository;

    @Autowired
    private TreeSurveyMasterRepository treeSurveyMasterRepository;

    @Autowired
    private CuttingAndPruningMasterRepository cuttingAndPruningMasterRepository;

    @Transactional
    public List<TreeCuttingPruningDetails> save(List<Integer> treeSurveyMasterIds, int cuttingAndPruningMasterId) {
        List<TreeCuttingPruningDetails> detailsList = new ArrayList<>();

        CuttingAndPruningMaster cuttingAndPruningMaster = cuttingAndPruningMasterRepository.findById(cuttingAndPruningMasterId)
                .orElseThrow(() -> new RuntimeException("CuttingAndPruningMaster not found"));

        for (int treeSurveyMasterId : treeSurveyMasterIds) {
            TreeSurveyMaster treeSurveyMaster = treeSurveyMasterRepository.findById(treeSurveyMasterId)
                    .orElseThrow(() -> new RuntimeException("TreeSurveyMaster not found"));

            TreeCuttingPruningDetails details = new TreeCuttingPruningDetails();
            details.setTreeSurveyMaster(treeSurveyMaster);
            details.setCuttingAndPruningMaster(cuttingAndPruningMaster);

            // Map fields from related entities
            details.setTreeName(treeSurveyMaster.getLocalName());
            details.setUuidNo(treeSurveyMaster.getTreeUUID());
            details.setCuttPurnRequestRemarks(cuttingAndPruningMaster.getRequestRemarks());

            detailsList.add(details);
        }

        return repository.saveAll(detailsList);
    }

    public Optional<TreeCuttingPruningDetails> findById(int id) {
        return repository.findById(id);
    }

    public List<TreeCuttingPruningDetails> findByCuttingAndPruningMasterId(int cuttingAndPruningMasterId) {
        return repository.findByCuttingAndPruningMasterId(cuttingAndPruningMasterId);
    }
}
