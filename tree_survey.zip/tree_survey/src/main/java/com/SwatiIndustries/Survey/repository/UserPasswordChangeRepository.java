package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.UserInfo;
import com.SwatiIndustries.Survey.model.UserMaster;
import com.SwatiIndustries.Survey.model.UserPasswordChange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface UserPasswordChangeRepository extends JpaRepository<UserPasswordChange, Integer> {
    Optional<UserPasswordChange> findByUserMaster(UserMaster userMaster);
}
