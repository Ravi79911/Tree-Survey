package com.SwatiIndustries.Survey.model;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "Tbl_complain_mitization_Details")
public class ComplainMitigationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id;

    @Column(name = "forward_date")
    private LocalDateTime forwardDate;

    @Column(name = "forward_from")
    private String forwardFrom;

    @Column(name = "forward_to")
    private String forwardTo;

    @Column(name = "forward_remaks")
    private String forwardRemaks;

    @Column(name = "Forward_status")
    private String forwardStatus;

    @Column(name = "created_By")
    private int createdBy;

    @Column(name = "created_Date")
    private LocalDateTime createdDate;

    @ManyToOne
    @JoinColumn(name = "cutting_purning_mas_id", nullable = false)
    private CuttingAndPruningMaster cuttingAndPruningMaster;

}