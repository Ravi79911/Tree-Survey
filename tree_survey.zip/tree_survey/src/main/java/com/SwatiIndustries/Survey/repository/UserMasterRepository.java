package com.SwatiIndustries.Survey.repository;

import com.SwatiIndustries.Survey.model.UserMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;


@EnableJpaRepositories
public interface UserMasterRepository extends JpaRepository<UserMaster, Integer> {
    List<UserMaster> findBySuspendedStatus(Integer suspendedStatus);
}
