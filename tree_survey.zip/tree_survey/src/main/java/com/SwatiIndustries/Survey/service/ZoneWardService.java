package com.SwatiIndustries.Survey.service;

import com.SwatiIndustries.Survey.dto.ZoneWardDto;
import com.SwatiIndustries.Survey.model.ZoneWard;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface ZoneWardService {

    ZoneWard createZoneWard(ZoneWard zoneWard);

    List<ZoneWardDto> getAllZoneWard();

    List<ZoneWard> getByWardNo(String wardNo);

    List<ZoneWard> getZoneWardByMunicipalId(int municipalId);

    //List<ZoneWard> getZoneById(int zoneId);

    Optional<ZoneWard> getZoneWardById(int id);

   // ZoneWard updateZoneWard(int id, ZoneWard zoneWard);

   // ZoneWard patchSuspendedStatus(int id, int suspendedStatus);
   public List<ZoneWardDto> getZoneWardsByZoneId(int zoneId);

}
