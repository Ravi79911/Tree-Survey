package com.SwatiIndustries.Survey.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "tbl_municipal_masters")
public class MunicipalMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "municipal_id")
    private int id;

    @NotBlank(message = "municipal code cannot be blank")
    @Column(name = "muni_code")
    private String muniCode;

    @NotBlank(message = "municipal name cannot be blank")
    @Column(name = "muni_name")
    private String muniName;

    @NotBlank(message = "city cannot be blank")
    @Column(name = "city")
    private String city;

    @NotBlank(message = "state cannot be blank")
    @Column(name = "state")
    private String state;

    @NotBlank(message = "address line 1 cannot be blank")
    @Column(name = "address_line1")
    private String addressLine1;

    @Column(name = "address_line2")
    private String addressLine2;

    @NotBlank(message = "commis name cannot be blank")
    @Column(name = "commis_name")
    private String commisName;

    @Pattern(regexp = "^\\+?[0-9. ()-]{7,25}$", message = "invalid contact number")
    @Column(name = "contact_no")
    private String contactNumber;

    @Pattern(regexp = "^\\+?[0-9. ()-]{7,25}$", message = "invalid toll-free number")
    @Column(name = "tollfree_no")
    private String tollFreeNumber;

    @Column(name = "logo_file")
    private String logoFile;

    @Positive(message = "created by must be a positive number")
    @Column(name = "created_by")
    private int createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Positive(message = "updated by must be a positive number")
    @Column(name = "updated_by")
    private int updatedBy;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    
    @Column(name = "suspended_status")
    private int suspendedStatus;


    @OneToMany(mappedBy = "municipalMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Zone> zones;

    @OneToMany(mappedBy = "municipalMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ZoneWard> zoneWards;

    @OneToMany(mappedBy = "municipalMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<TreeSurveyMaster> treeSurveyMasters;

    @OneToMany(mappedBy = "municipalMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<CuttingAndPruningMaster> cuttingAndPruningMasters;

    @OneToMany(mappedBy = "municipalMaster", cascade = CascadeType.ALL)
    private Set<UserRoleMaster> userRoleMasters;

    @OneToMany(mappedBy = "municipalMasterid", cascade = CascadeType.ALL)
    private Set<UserMaster> userMasters;

    @OneToMany(mappedBy = "municipalMaster", cascade = CascadeType.ALL)
    private Set<ApprovalMappingDetails> approvalMappingDetails;




}
